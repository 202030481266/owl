# Federated Learning: A Survey on Privacy-Preserving Collaborative Intelligence  

Edward Collins, Michel Wang Department of Computer Engineering, Arizona State University, Arizona, USA.  

Abstract—Federated Learning (FL) has emerged as a transformative paradigm in the field of distributed machine learning, enabling multiple clients—such as mobile devices, edge nodes, or organizations—to collaboratively train a shared global model without the need to centralize sensitive data. This decentralized approach addresses growing concerns around data privacy, security, and regulatory compliance, making it particularly attractive in domains such as healthcare, finance, and smart IoT systems. This survey provides a concise yet comprehensive overview of Federated Learning, beginning with its core architecture and communication protocol. We discuss the standard FL lifecycle, including local training, model aggregation, and global updates. A particular emphasis is placed on key technical challenges such as handling non-IID (non-independent and identically distributed) data, mitigating system and hardware heterogeneity, reducing communication overhead, and ensuring privacy through mechanisms like differential privacy and secure aggregation. Furthermore, we examine emerging trends in FL research, including personalized FL, cross-device versus cross-silo settings, and integration with other paradigms such as reinforcement learning and quantum computing. We also highlight real-world applications and summarize benchmark datasets and evaluation metrics commonly used in FL research. Finally, we outline open research problems and future directions to guide the development of scalable, efficient, and trustworthy FL systems.  

# I. INTRODUCTION  

In recent years, the landscape of machine learning (ML) has been rapidly transformed by the explosive growth in data generation from edge devices such as smartphones, wearables, autonomous vehicles, and smart sensors. These devices collectively generate petabytes of data daily, representing a vast and valuable source of information for training intelligent systems [1], [2]. However, centralizing such data in cloud servers for model training has become increasingly impractical due to multiple limitations—chief among them being privacy concerns, communication overhead, and compliance with data protection regulations such as the General Data Protection Regulation (GDPR) and the Health Insurance Portability and Accountability Act (HIPAA) [3].  

Federated Learning (FL), proposed by McMahan et al. [4], addresses these limitations by introducing a collaborative yet privacy-preserving machine learning framework. In FL, training is conducted locally on edge devices or institutional servers, and only model updates (e.g., weights or gradients) are transmitted to a central aggregator. This paradigm allows raw data to remain decentralized, ensuring both privacy preservation and reduced bandwidth consumption. A central server then performs aggregation, most commonly using Federated  

Averaging (FedAvg), to update the global model iteratively [4].  

FL has quickly evolved from its original scope—primarily involving mobile devices in cross-device scenarios—to more complex, structured environments such as cross-silo learning, where institutions like hospitals, banks, or universities collaboratively train models on sensitive datasets [5]. These two categories present vastly different challenges. Cross-device FL must contend with large-scale, unreliable, and computationally limited clients, while cross-silo FL emphasizes security, trust, and statistical heterogeneity among fewer but more powerful clients [2].  

One of the most pressing technical challenges in FL is the presence of statistical heterogeneity or non-IID (nonindependent and identically distributed) data across clients. Since each client’s data may be generated under different distributions—due to geographic, demographic, or temporal variations—traditional centralized learning assumptions often do not hold in federated settings [1], [6]. This heterogeneity can significantly degrade convergence speed and model accuracy, necessitating robust aggregation strategies, personalized learning techniques, and client clustering mechanisms [7], [8].  

Moreover, FL must cope with system-level heterogeneity, where client devices vary in terms of computing power, memory, battery life, and network connectivity [9]. Solutions such as asynchronous training, partial participation, and client selection heuristics have been proposed to alleviate these constraints [10], [11]. Communication efficiency is another core issue, as iterative communication rounds can be costly and slow in real-world deployments. Techniques such as update compression, quantization, and sparsification have emerged to reduce the size of model updates and improve communication throughput [12].  

Privacy remains central to the FL paradigm. While FL inherently reduces data exposure, model updates may still leak sensitive information through gradient inversion attacks or malicious aggregation [13]. To counter such risks, researchers have developed secure aggregation protocols [14] and incorporated differential privacy mechanisms at the client level [15]. These methods offer mathematical guarantees of privacy, albeit at the cost of reduced model accuracy or increased computation.  

The field of FL continues to grow, integrating innovations from other domains such as reinforcement learning [16], multi-task learning [7], blockchain [17], and even quantum computing [18]. These interdisciplinary expansions aim to enhance FL’s scalability, robustness, and privacy assurances. Applications of FL have already made impactful inroads in healthcare (e.g., disease diagnosis from medical imaging), finance (e.g., fraud detection), smart cities (e.g., traffic prediction), and natural language processing (e.g., next-word prediction in mobile keyboards) [19], [20].  

This survey offers a concise yet comprehensive overview of Federated Learning. We begin by outlining its foundational concepts and architectural designs, followed by an analysis of its key challenges, including statistical and system heterogeneity, communication bottlenecks, and privacy threats. We then review recent innovations and practical implementations across various domains. Finally, we discuss ongoing research trends and open problems, laying the groundwork for future exploration and advancement in this promising field.  

# II. SYSTEM ARCHITECTURE  

Federated Learning (FL) operates under a client-server architecture, where a global model is collaboratively trained by multiple clients without exchanging their raw data. This architecture is designed to preserve data privacy, reduce communication overhead, and enable scalability across diverse hardware environments [2], [5], [21]. In this section, we describe the core architectural components of a typical FL system, focusing on both centralized and decentralized settings.  

# A. Centralized Federated Learning  

In the standard FL setting introduced by McMahan et al. [4], a central coordinator (or server) orchestrates the training process. The architecture consists of three main stages: (1) the server distributes the current global model to selected clients; (2) clients perform local training using their private data; and (3) the server aggregates the clients’ updates to form a new global model. This process is repeated iteratively until convergence.  

The most commonly used aggregation algorithm is Federated Averaging (FedAvg), where each client trains the model for a few epochs and sends updated parameters to the server. The server then performs a weighted average of the received updates based on the clients’ local data sizes [4].  

# B. Decentralized and Peer-to-Peer FL  

To mitigate the single point of failure and trust issues associated with centralized architectures, decentralized FL frameworks have emerged. In such systems, clients coordinate among themselves without relying on a central server [22]– [24]. Techniques such as gossip-based communication, ring topologies, and blockchain are used to enable secure and robust peer-to-peer model sharing.  

For example, blockchain-integrated FL ensures tamperproof logging of updates and consensus-driven aggregation without a centralized entity [17]. While these methods increase resilience and transparency, they often incur additional latency and computational complexity.  

# C. Client Selection and Participation  

Client selection plays a critical role in FL system design. Due to the dynamic availability and heterogeneity of clients, it is not feasible to engage all participants in every training round [10]. Scheduling algorithms aim to select a subset of clients based on availability, resource capability, data quality, and fairness. Random selection, importance sampling, and reinforcement learning-based schedulers have been proposed to optimize this process [25].  

# D. Communication Protocols  

Efficient communication is essential in FL systems, especially in cross-device scenarios where bandwidth is limited. FL protocols are designed to minimize the number of communication rounds and the size of transmitted updates. Common strategies include:  

• Model Compression: Reducing the size of transmitted gradients using quantization, sparsification, or pruning techniques [12].   
• Asynchronous Communication: Allowing clients to send updates independently to reduce idle time and mitigate straggler effects [26].   
• Secure Aggregation: Ensuring that the server cannot infer any individual client’s model update by using cryptographic protocols [14].  

# E. System Heterogeneity  

FL systems must operate across a wide spectrum of hardware capabilities. Clients differ in processing power, memory, battery life, and network reliability. To address these constraints, FL architectures implement adaptive mechanisms such as partial training, early stopping, and resource-aware client selection [2].  

Overall, the FL system architecture must strike a balance between accuracy, privacy, communication efficiency, and scalability. As FL continues to evolve, emerging architectures are exploring hybrid decentralized models, hierarchical aggregation, and edge-cloud collaboration [27].  

# III. CHALLENGES IN FEDERATED LEARNING  

Despite its advantages in preserving privacy and reducing data transmission costs, Federated Learning (FL) introduces a wide range of technical, statistical, and practical challenges that distinguish it from conventional centralized machine learning. These challenges must be carefully addressed to enable robust, scalable, and secure FL deployments in realworld scenarios.  

# A. Statistical Heterogeneity  

A major challenge in FL is the statistical heterogeneity of client data. Unlike centralized settings where data can be assumed to be independent and identically distributed (IID), FL operates in environments where each client’s local dataset is often non-IID due to variations in geography, behavior, usage patterns, and sensor configurations [1], [6]. This discrepancy can lead to significant performance degradation, poor generalization, and slower convergence [2]. Several strategies, such as client clustering [28], meta-learning [29], and personalized federated models [7], have been proposed to mitigate the effects of data heterogeneity.  

# B. System Heterogeneity  

In cross-device FL scenarios, clients often have different hardware capabilities, network conditions, energy limitations, and storage capacities [5], [10]. Some devices may be unable to participate consistently due to battery constraints or intermittent connectivity. These disparities result in stragglers and idle server wait times, ultimately impacting the efficiency and fairness of the training process. Adaptive client selection [25], partial updates, and resource-aware scheduling [30] are common methods to manage this heterogeneity.  

# C. Communication Bottlenecks  

Communication cost is a dominant concern in FL, especially when dealing with large-scale models and millions of clients. The iterative nature of FL requires frequent exchange of model updates between clients and the server, which can be prohibitively expensive in bandwidth-limited environments [9]. Solutions to this challenge include:  

• Model Update Compression: Techniques such as quantization, sparsification, and subsampling reduce the size of messages transmitted during each round [12].   
• Periodic Aggregation: Reducing the number of communication rounds by allowing multiple local updates before synchronizing [4].   
• Asynchronous Communication: Allowing clients to communicate and update independently without synchronized global rounds [26].  

# D. Privacy and Security Threats  

Although FL is inherently privacy-preserving by design, it is still vulnerable to various attacks:  

• Inference Attacks: Malicious servers or adversarial clients can reconstruct sensitive data from model updates via gradient inversion techniques [31].   
• Backdoor Attacks: A malicious client can inject poisoned updates to implant backdoors in the global model [13].   
• Data Leakage via Updates: Even without direct access to raw data, unprotected gradient sharing can reveal information about client datasets.  

To mitigate these risks, techniques such as differential privacy [15], secure multiparty computation [14], and robust aggregation mechanisms [32] have been integrated into FL protocols.  

# E. Client Dropout and Participation Variability  

In practical FL deployments, especially in cross-device scenarios, clients may frequently drop out due to connectivity issues, energy constraints, or user preferences [10]. This leads to dynamic participation rates and complicates global convergence guarantees. Addressing this issue involves designing fault-tolerant aggregation algorithms and flexible participation incentives [2].  

# F. Fairness and Personalization  

Uniform model optimization across all clients may result in suboptimal performance for users with unique or minority data distributions. This raises fairness concerns, particularly in sensitive applications like healthcare or finance [33]. To address this, personalized FL frameworks have been proposed, where each client adapts the global model to its own data distribution via local fine-tuning, model interpolation, or multitask learning [7], [34].  

# G. Scalability and Resource Allocation  

Scalability remains a critical barrier to FL’s widespread adoption. Efficient orchestration of thousands or millions of devices demands robust infrastructure for model update management, bandwidth allocation, and aggregation optimization [5], [10]. Hierarchical FL architectures and edge-server-based hybrid approaches are gaining traction to address these scalability limitations [27].  

# H. Evaluation and Benchmarking  

Unlike conventional ML tasks, evaluating FL algorithms requires considering multiple dimensions such as communication cost, training time, convergence rate, model accuracy, client fairness, and privacy guarantees. There is currently a lack of standardized benchmarking frameworks for FL, although efforts such as LEAF [35] and OARF [36] are emerging to address this gap.  

In summary, FL introduces several novel challenges that span statistical learning, distributed systems, security, and fairness. Addressing these challenges requires cross-disciplinary solutions that combine optimization theory, privacy-enhancing technologies, and systems engineering.  

# IV. APPLICATIONS OF FEDERATED LEARNING  

Federated Learning (FL) has garnered significant attention across a range of industries where privacy, data ownership, and regulatory compliance are paramount. The ability to train machine learning models across decentralized data silos without moving sensitive information makes FL a highly attractive solution in sectors such as healthcare, finance, mobile systems, smart cities, grids [37], and industrial IoT.  

# A. Healthcare  

FL is particularly well-suited for healthcare, where patient privacy and regulatory restrictions prevent the sharing of medical data across institutions. Hospitals and research centers can collaboratively train diagnostic models on local data, improving performance without compromising privacy [20]. Applications include disease detection using imaging data (e.g., MRI, CT scans), electronic health record (EHR) analysis, and predictive analytics for early intervention [38], [39].  

# B. Finance  

In the financial sector, banks and credit institutions utilize FL to detect fraud, assess credit risk, and prevent money laundering while keeping customer data private and locally stored [3]. Federated models can be trained on transaction patterns across institutions to enhance anomaly detection systems and personalize financial services [40].  

# C. Smartphones and Edge Devices  

One of the earliest and most prominent applications of FL is in mobile devices. Google has used FL to improve nextword prediction and emoji suggestions on Android keyboards without accessing user data directly [19]. Similar applications include on-device speech recognition, personalization of recommendation systems, and activity tracking [10].  

# D. Smart Cities and Industrial IoT  

FL enables cities and industrial environments to collaboratively train models for traffic prediction, energy optimization, pollution detection, and equipment failure forecasting, without centralizing sensor data [41]. In smart transportation, edge nodes embedded in vehicles and infrastructure use FL to build collaborative models for route optimization, collision avoidance, and driver behavior analysis [42].  

# E. Natural Language Processing and Multilingual Systems  

FL is increasingly being applied to natural language tasks where sensitive user input is common. Applications include personalized language modeling, sentiment classification, and spam detection in decentralized environments. Additionally, multilingual FL has been explored to train cross-lingual models without aggregating text data into a central repository [43].  

# F. Collaborative Robotics and Federated Reinforcement Learning  

Emerging applications of FL are also found in multiagent systems such as collaborative robotics and autonomous vehicles. Federated Reinforcement Learning (FRL) allows distributed agents to learn optimal policies from their local environments while sharing abstract knowledge with peers [16]. This is particularly useful in scenarios where shared realworld training is infeasible or costly.  

As adoption continues to grow, FL is expected to become a backbone technology for privacy-preserving AI across both consumer and enterprise ecosystems.  

# A. Differential Privacy  

Differential Privacy (DP) provides a rigorous mathematical framework to limit the amount of information that can be inferred about any individual client or data point from the trained model [44]. In FL, client-side DP is commonly implemented by adding calibrated noise to local gradients or model updates before they are shared with the server [15]. Although DP helps reduce information leakage, it often introduces a trade-off between model accuracy and privacy, especially in small or skewed datasets [45].  

# B. Secure Multiparty Computation and Homomorphic Encryption  

Secure Multiparty Computation (SMC) enables multiple parties to jointly compute a function over their inputs while keeping those inputs private [46]. In FL, SMC protocols are used to compute model aggregates without revealing individual updates. One well-known implementation is the secure aggregation protocol by Bonawitz et al., which ensures that the server learns only the aggregated model, not the contributions of individual clients [14].  

Homomorphic Encryption (HE) allows computations to be performed directly on encrypted data. Clients can encrypt their model updates, which the server can aggregate without decrypting. While HE provides strong cryptographic privacy guarantees, it is computationally intensive and often impractical for resource-constrained devices [47].  

# C. Robust Aggregation Against Adversaries  

FL is vulnerable to adversarial attacks, including model poisoning, data poisoning, and backdoor attacks. A single compromised client can manipulate local updates to degrade or subvert the global model [13]. To mitigate this, robust aggregation methods have been developed:  

Krum: Selects a client update that is closest (in Euclidean distance) to the majority of other updates [32]. • Trimmed Mean and Median: Excludes outliers or computes the coordinate-wise median to tolerate Byzantine clients [48]. • FoolsGold: Identifies clients with similar gradients to prevent sybil-based poisoning attacks [49].  

# D. Gradient Obfuscation and Perturbation  

Gradient leakage attacks can recover private data from shared gradients [31]. To protect against such inference, obfuscation techniques modify gradients through dropout, quantization, or randomized masking. These methods aim to reduce the information content of the gradients without significantly affecting training performance.  

# V. PRIVACY AND SECURITY TECHNIQUES E. Trusted Execution Environments (TEEs)  

While Federated Learning (FL) is designed to be privacypreserving by keeping raw data local to clients, it is still susceptible to various privacy and security threats. Malicious adversaries can exploit shared model updates to infer sensitive information or corrupt the training process. Therefore, FL requires robust privacy-enhancing techniques and secure communication protocols to mitigate these vulnerabilities.  

Trusted Execution Environments, such as Intel SGX, provide hardware-based secure enclaves where computations can be performed in an isolated and tamper-proof environment [50]. TEEs can be used at the server or client side to protect both training and aggregation processes. Although TEEs offer strong security guarantees, their availability and scalability remain limited in large-scale FL deployments.  

# F. Blockchain and Auditability  

To enhance transparency and trust, some FL frameworks integrate blockchain for immutable logging and decentralized coordination [17]. This provides audit trails and incentivizes honest participation through token-based systems. However, blockchain integration introduces latency and energy concerns that must be carefully managed.  

In conclusion, privacy and security in FL is an active area of research. Future advancements will likely combine cryptographic methods, statistical guarantees, and system-level protections to deliver end-to-end secure federated systems.  

# VI. CONCLUSION AND FUTURE DIRECTIONS  

Federated Learning (FL) has emerged as a powerful paradigm for privacy-preserving collaborative machine learning, enabling the development of robust models across decentralized data sources. This survey has presented a comprehensive overview of FL, covering its system architectures, core challenges, applications, and privacy-enhancing techniques. Through diverse real-world use cases—from healthcare to smart cities—FL has demonstrated its capability to bridge data utility and privacy. Despite its promise, FL still faces significant limitations in scalability, personalization, fairness, communication efficiency, and security. Addressing these limitations requires a multifaceted approach that combines innovations in optimization algorithms, privacy-preserving technologies, distributed systems, and secure hardware.  

Several promising research directions are currently shaping the future of FL:  

• Personalized Federated Learning: Tailoring global models to individual client distributions remains an open challenge. Approaches such as multi-task learning [7], model interpolation [34], and local fine-tuning offer potential, but need further scalability analysis and formal guarantees.   
• Cross-Silo and Cross-Device Integration: Bridging the gap between cross-silo (e.g., hospitals) and cross-device (e.g., smartphones) FL requires unified protocols that can adapt to both reliable and volatile client behaviors [5].   
• Trustworthy FL: Building trust in FL systems requires advances in verifiable aggregation, auditability, and incentive mechanisms for honest participation. Blockchainbased FL and trusted hardware solutions like TEEs are promising directions [17], [50]. Quantum and Federated Synergy: With the advent of quantum computing, integrating quantum machine learning with FL (i.e., Federated Quantum Learning) opens new possibilities for optimization and privacy [18].   
• Benchmarking and Standardization: The lack of standardized benchmarks and reproducibility in FL research limits meaningful comparisons across methods. Initiatives like LEAF [35] and FedML [51] are important steps toward creating shared evaluation frameworks.   
• Green FL: As FL becomes more ubiquitous, its energy consumption and environmental impact need to be considered. Energy-efficient FL protocols and hardwareaware training pipelines are critical for sustainable deployment [41].  

In summary, Federated Learning is a rapidly evolving field at the intersection of machine learning, privacy, and distributed systems. Continued interdisciplinary research and practical innovations will be key to unlocking its full potential in creating scalable, secure, and equitable AI systems.  

#  

REFERENCES   
[1] Y. Zhao, M. Li, M. Lai, N. Suda, D. Civin, and V. Chandra, “Federated learning with non-iid data,” arXiv preprint arXiv:1806.00582, 2018.   
[2] T. Li, A. K. Sahu, A. Talwalkar, and V. Smith, “Federated learning: Challenges, methods, and future directions,” IEEE Signal Processing Magazine, vol. 37, no. 3, pp. 50–60, 2020.   
[3] Q. Yang, Y. Liu, T. Chen, and Y. Tong, “Federated machine learning: Concept and applications,” ACM Transactions on Intelligent Systems and Technology (TIST), vol. 10, no. 2, pp. 1–19, 2019.   
[4] H. B. McMahan, E. Moore, D. Ramage, S. Hampson et al., “Communication-efficient learning of deep networks from decentralized data,” Proceedings of the 20th International Conference on Artificial Intelligence and Statistics (AISTATS), 2017.   
[5] P. Kairouz, H. B. McMahan et al., “Advances and open problems in federated learning,” arXiv preprint arXiv:1912.04977, 2019.   
[6] T. Hsu, H. Qi, and M. Brown, “Measuring the effects of non-identical data distribution for federated visual classification,” arXiv preprint arXiv:1909.06335, 2019.   
[7] V. Smith, C.-K. Chiang, M. Sanjabi, and A. Talwalkar, “Federated multitask learning,” Advances in Neural Information Processing Systems (NeurIPS), 2017.   
[8] T. Li, A. K. Sahu, M. Sanjabi, A. Talwalkar, and V. Smith, “Ditto: Fair and robust federated learning through personalization,” Proceedings of the 38th International Conference on Machine Learning (ICML), 2021.   
[9] J. Konecˇny\`, H. B. McMahan, F. X. Yu, P. Richta´rik, A. T. Suresh, and D. Bacon, “Federated optimization: Distributed optimization beyond the datacenter,” in Proceedings of the 4th International Conference on Machine Learning (ICML) Workshop on Distributed Machine Learning, 2016.   
[10] K. Bonawitz, H. Eichner, W. Grieskamp, D. Huba, A. Ingerman, V. Ivanov, C. Kiddon, J. Konecˇny´, S. Mazzocchi, H. B. McMahan et al., “Towards federated learning at scale: System design,” in Proceedings of the 2nd SysML Conference, 2019.   
[11] A. Smith, B. Johnson, and M. Geller, “Integrating personalized federated learning with control systems for enhanced performance,” arXiv preprint arXiv:2501.15728, 2025.   
[12] A. Reisizadeh, A. Mokhtari, H. Hassani, A. Jadbabaie, and R. Pedarsani, “Fedpaq: A communication-efficient federated learning method with periodic averaging and quantization,” International Conference on Artificial Intelligence and Statistics (AISTATS), pp. 2021–2031, 2020.   
[13] E. Bagdasaryan, A. Veit, Y. Hua, D. Estrin, and V. Shmatikov, “How to backdoor federated learning,” Proceedings of the 23rd International Conference on Artificial Intelligence and Statistics (AISTATS), 2020.   
[14] K. Bonawitz, V. Ivanov, B. Kreuter, A. Marcedone, H. B. McMahan, S. Patel, D. Ramage, A. Segal, and K. Seth, “Practical secure aggregation for privacy-preserving machine learning,” in Proceedings of the 2017 ACM SIGSAC Conference on Computer and Communications Security (CCS), 2017, pp. 1175–1191.   
[15] R. C. Geyer, T. Klein, and M. Nabi, “Differentially private federated learning: A client level perspective,” arXiv preprint arXiv:1712.07557, 2017.   
[16] C. Zhang, Y. Zhang et al., “Federated reinforcement learning: Techniques, applications, and opportunities,” IEEE Transactions on Neural Networks and Learning Systems, 2021.   
[17] S. Pokhrel and J. H. Choi, “Federated learning meets blockchain at the edge: A survey and future directions,” IEEE Communications Surveys & Tutorials, vol. 22, no. 3, pp. 2001–2031, 2020.   
[18] S. Yang, Y. Wu, L. Pan, L. Li, Z. Wang, J. Yang, and L. Xie, “Federated quantum machine learning,” npj Quantum Information, vol. 7, no. 1, pp. 1–8, 2021.   
[19] A. Hard, K. Rao, R. Mathews, S. Ramaswamy, F. Beaufays, S. Augenstein, H. Eichner, C. Kiddon, and D. Ramage, “Federated learning for mobile keyboard prediction,” in Proceedings of the 21st International Conference on Artificial Intelligence and Statistics (AISTATS), 2018.   
[20] N. Rieke, J. Hancox, W. Li, F. Milletari, H. R. Roth, S. Albarqouni, S. Bakas, M. Galtier, B. Landman, K. H. Maier-Hein et al., “The future of digital health with federated learning,” npj Digital Medicine, vol. 3, no. 1, pp. 1–7, 2020.   
[21] R. Rahman and D. C. Nguyen, “Improved modulation recognition using personalized federated learning,” IEEE Transactions on Vehicular Technology, 2024.   
[22] B. He, X. Chen, D. Jin, and L. Chen, “Fedgcn: Federated graph convolutional learning with privacy preservation,” IEEE Transactions on Knowledge and Data Engineering, 2021.   
[23] A. Lalitha, T. Javidi, and G. Michailidis, “Peer-to-peer federated learning on graphs,” in International Conference on Machine Learning (ICML) Workshop on Federated Learning for Data Privacy and Confidentiality, 2019.   
[24] B. Johnson and M. Geller, “Meta-federated learning: A novel approach for real-time traffic flow management,” arXiv preprint arXiv:2501.16758, 2025.   
[25] T. Nishio and R. Yonetani, “Client selection for federated learning with heterogeneous resources in mobile edge,” in IEEE International Conference on Communications (ICC). IEEE, 2019, pp. 1–7.   
[26] C. Xie, O. Koyejo, and I. Gupta, “Asynchronous federated optimization,” arXiv preprint arXiv:1903.03934, 2019.   
[27] Y. Lu, X. Huang, Y. Dai, S. Maharjan, and Y. Zhang, “Federated learning for data privacy preservation in vehicular cyber-physical systems,” IEEE Network, vol. 34, no. 3, pp. 50–56, 2020.   
[28] A. Ghosh, J. Chung, D. Yin, and K. Ramchandran, “Efficient model aggregation in federated learning,” Advances in Neural Information Processing Systems (NeurIPS), 2020.   
[29] A. Fallah, A. Mokhtari, and A. Ozdaglar, “Personalized federated learning with meta-learning,” Advances in Neural Information Processing Systems (NeurIPS), 2020.   
[30] S. Wang, T. Tuor, T. Salonidis, K. K. Leung, C. Makaya, T. He, and K. Chan, “Optimizing federated learning on non-iid data with reinforcement learning,” IEEE Journal on Selected Areas in Communications, vol. 38, no. 10, pp. 2396–2411, 2020.   
[31] L. Zhu, Z. Liu, and S. Han, “Deep leakage from gradients,” Advances in Neural Information Processing Systems (NeurIPS), 2019.   
[32] P. Blanchard, E. M. El Mhamdi, R. Guerraoui, and J. Stainer, “Machine learning with adversaries: Byzantine tolerant gradient descent,” Advances in Neural Information Processing Systems (NeurIPS), 2017.   
[33] T. Li, A. K. Sahu, A. Talwalkar, and V. Smith, “Fair resource allocation in federated learning,” arXiv preprint arXiv:1905.10497, 2019.   
[34] C. T. Dinh, N. H. Tran, T. T. Nguyen, D. Nguyen, and C. S. Hong, “Personalized federated learning with moreau envelopes,” Advances in Neural Information Processing Systems (NeurIPS), 2020.   
[35] S. Caldas, P. Wu, T. Li, J. Konecˇny´, H. B. McMahan, V. Smith, and A. Talwalkar, “Leaf: A benchmark for federated settings,” arXiv preprint arXiv:1812.01097, 2018.   
[36] C. He, M. Annavaram, and S. Avestimehr, “Oarf: Towards open, adaptable and reproducible federated learning research,” in Proceedings of the NeurIPS Workshop on Scalability, Privacy, and Security in Federated Learning, 2020.   
[37] R. Rahman, P. Moriano, S. U. Khan, and D. C. Nguyen, “Electrical load forecasting over multihop smart metering networks with federated learning,” arXiv preprint arXiv:2502.17226, 2025.   
[38] T. S. Brisimi, R. Chen, T. Mela, A. Olshevsky, I. C. Paschalidis, and W. Shi, “Federated learning of predictive models from federated electronic health records,” International Journal of Medical Informatics, vol. 112, pp. 59–67, 2018.   
[39] M. J. Sheller, B. Edwards, G. A. Reina, J. Martin, S. Pati, A. Kotrotsou, M. Milchenko, W. Xu, D. Marcus, R. R. Colen, and S. Bakas, “Federated learning in medicine: facilitating multi-institutional collaborations without sharing patient data,” in Scientific Reports, vol. 10, no. 1, 2020, pp. 1–12.   
[40] G. Long, L. Liu, T. Shen, J. Jiang, and C. Zhang, “Federated learning for open banking,” arXiv preprint arXiv:2009.06612, 2020.   
[41] W. Y. B. Lim, N. C. Luong, D. Hoang, Y. Jiao, Y.-C. Liang, Q. Yang, D. Niyato, C. Miao, and H. V. Poor, “Federated learning in mobile edge networks: A comprehensive survey,” IEEE Communications Surveys & Tutorials, vol. 22, no. 3, pp. 2031–2063, 2020.   
[42] Y. Saputra, L. Huynh, D. T. Hoang, D. T. Nguyen, and E. Dutkiewicz, “Energy-efficient federated learning for vehicle-to-everything (v2x) communications,” in IEEE International Conference on Communications (ICC), 2019, pp. 1–6.   
[43] T. Lin, L. Kong, S. U. Stich, and M. Jaggi, “Ensemble distillation for robust model fusion in federated learning,” Advances in Neural Information Processing Systems (NeurIPS), 2020.   
[44] C. Dwork and A. Roth, The algorithmic foundations of differential privacy. Foundations and Trends in Theoretical Computer Science, 2014.   
[45] M. Abadi, A. Chu, I. Goodfellow, H. B. McMahan, I. Mironov, K. Talwar, and L. Zhang, “Deep learning with differential privacy,” Proceedings of the 2016 ACM SIGSAC Conference on Computer and Communications Security (CCS), pp. 308–318, 2016.   
[46] A. C. Yao, “Protocols for secure computations,” in Proceedings of the 23rd Annual Symposium on Foundations of Computer Science (FOCS), 1982, pp. 160–164.   
[47] Y. Aono, T. Hayashi, L. Wang, and S. Moriai, “Privacy-preserving deep learning via additively homomorphic encryption,” in IEEE Transactions on Information Forensics and Security, vol. 13, no. 5, 2017, pp. 1333– 1345.   
[48] D. Yin, Y. Chen, R. Kannan, and P. Bartlett, “Byzantine-robust distributed learning: Towards optimal statistical rates,” International Conference on Machine Learning (ICML), 2018.   
[49] C. Fung, C. Yoon, and I. Beschastnikh, “Mitigating sybils in federated learning poisoning,” in Proceedings of the 21st International Symposium on Research in Attacks, Intrusions and Defenses (RAID), 2018.   
[50] X. Mo, Y. Hu, Y. Li, Z. Yu, C. Wang, and W. Xu, “Ppfl: Privacypreserving federated learning with trusted execution environments,” in IEEE INFOCOM 2021-IEEE Conference on Computer Communications, 2021, pp. 160–169.   
[51] C. He, M. Annavaram, and S. Avestimehr, “Fedml: A research library and benchmark for federated machine learning,” arXiv preprint arXiv:2007.13518, 2020.  

This figure "overview.png" is available in "png"
 format from: http://arxiv.org/ps/2504.17703v1  