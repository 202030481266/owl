# On the Generalizability of Transformer Models to Code Completions of Different Lengths  

Nathan Cooper∗, Rosalia Tufano†, Gabriele Bavota†, Denys Poshyvanyk‡ ∗Stability AI, USA †Universit\`a della Svizzera italiana (USI), Switzerland ‡William & Mary, USA  

Abstract—The programming landscape is nowadays being reshaped by the advent of Large Language Models (LLMs) able to automate code-related tasks related to code implementation (e.g., code completion) and comprehension (e.g., code summarization). Such a paradigm shift comes with a number of implications related to how software will be written, maintained, and evolved. Also, these LLMs are extremely expensive to train, posing questions on their sustainability over time. Given their training cost, their ability to generalize, namely their ability to work on task instances different from those on which they have been trained, is an aspect worth being investigated. Previous work already showed that transformer models can successfully support code completion in a cross-project setting. However, it is unclear whether LLM are able to generalize to inputs having lengths not seen during training. For example, it is known that training a model on short instances allows to substantially reduce the training cost. However, the extent to which such a model would provide good performance on sequences having lengths not seen during training is not known. Many recent works in Natural Language Processing (NLP) tackled this problem in the context of decoder-only LLMs, i.e., xPOS and ALiBi. To assess if these solutions extend to encoder-decoder LLMs usually adopted in the code-related tasks, we present a large empirical study evaluating this generalization property of these and other encoding schemes proposed in the literature, namely Sinusoidal, xPOS, ALiBi, and T5. We found that none of these solutions successfully generalize to unseen lengths and that the only safe solution is to ensure the representativeness in the training set of all lengths likely to be encountered at inference time.  

Index Terms—DL4SE, Code Completion  

# I. INTRODUCTION  

Large Language Models (LLMs) for code have achieved state-of-the-art results across a variety of software engineering (SE) tasks such as code completion [1], [2], code reviews [3], code summarization [4], program repair [5], [6], testing [7], [8], and others [9], [10], [11]. The Transformers [12] have been at the center of these improvements due to its attention mechanism and ability to be highly parallelized, allowing for more efficient training compared to previous models such as Recurrent Neural Networks (RNN) [13].  

When applied to code completion, Transformers take as input an incomplete code component and try to predict the missing code tokens (e.g., [2], [14], [15], [16]). As already happened in the field of Natural Language Processing (NLP) [17], there has been a recent push in increasing the maximum length of the sequences (incomplete code components) on which Transformers are trained and tested.  

This is due to the fact that longer sequences (i) allow to provide the model with additional contextual information which can help with improving the prediction performance; and (ii) can help in simulating more variegate code completion scenarios. This, however, has a substantial cost to pay in terms of training time [18].  

It comes without surprise that efforts have been made in the NLP literature to address this issue (e.g., [19], [20], [18], [21]): The most recent work targets the generalization of Transformers to longer sequences than those they have been originally trained for [18], [21]. This allows to efficiently train a model on short sequences and, then, perform the inference on longer sequences without a significant performance degradation. This is, for instance, the goal of the ALiBi (Attention with Linear Biases) attention mechanism for Transformers [18], which has been successfully used in NLP.  

If solutions such as ALiBi properly work on source code as well, they could substantially help reduce the training cost of code completion models such as the popular GitHub Copilot [22]. This is the focus of our work. We aim to investigate the extent to which solutions proposed in the NLP literature can support the generalization of Transformers on source code. We focus on three state-of-the-art solutions and one baseline. The first (baseline), Sinusoidal [12], uses Absolution Positional Encodings (APEs) by defining sine and cosine functions to generate positional embeddings that the authors original hypothesized would help the model to generalize. The second, xPOS [23], [21], is a hybrid between APEs and Relative Positional Encodings (RPEs) and applies rotations to the sine and cosine positional embedding to incorporate relative position information along with a attention resolution metric to improve generalization. The third, ALiBi [18], offers a simple solution of modifying the attention mechanism to weight positions far away as less important than ones closer. The last, T5 [20], similarly modifies the attention mechanism by adding a learned bias term that influences the attention given to a token.  

We want to assess whether models trained on sequences of a specific length are able to generalize, i.e., not incur a significant performance degradation, on sequences being longer (or shorter) than the training ones. To accomplish this, we built four datasets (short, medium, long, and mix) featuring incomplete Python and Java functions having different lengths.  

![](images/8d83990cfec8dc7b01afe341fedc8ad2cf633f46db45e4e71a321354e51d32d4.jpg)  
Fig. 1. Sequence to Sequence Transformer Overview from the original paper [12]. The left part is the encoder and the right part is the decoder.  

Then, we train 32 Transformers, namely four models (Sinusoidal, xPOS, ALiBi, and T5) for each of the four datasets and two programming languages. The performance of the 32 models has been evaluated on a series of test sets of previously unseen Python and Java functions of various different lengths, studying the generalization of their predictions. For example, we verified if the models trained on short datasets are able to work on instances in the test set having a length inline with the examples in the long dataset.  

Overall, we make the following contributions:  

1) A systematic benchmark for evaluating the generalization of LLMs for code completion of different lengths across two programming languages;   
2) An empirical study on whether current generalization approaches extend to encoder-decoder architectures for the task of code completion;   
3) A set of results and implications that can be leveraged by researchers and developers of these models for navigating trade-offs.  

# II. BACKGROUND  

We introduce some mathematical background to understand the specifics of the position encoding schemes, namely Sinusoidal, xPOS, ALiBi, and Relative, and how they apply to our study. Our paper focuses on the Sequence to Sequence Transformer [12] (see Fig. 1). It takes as input a sequence of tokens $C^{\prime}=x_{1},x_{2},...,x_{n}$ (in our case, the code to be completed), and outputs a target sequence, $M$ , that is similarly decomposed into tokens $M=y_{1},y_{2},...,y_{m}$ .  

![](images/8b7a80d60942f324d61ea9d4d450cf4517f8dc48370988be3b23f6b52783bcf7.jpg)  
Fig. 2. ALiBi Overview from the original paper [18].  

$M$ represents in our context the missing piece of code to be predicted. Thus, the combination $C=C^{\prime}{+}M$ equals the complete code snippet. Note that the $+$ operator does not imply an append, but rather a combination regardless of where the missing part $M$ is placed in $C^{\prime}$ . The decomposition of both $C^{\prime}$ and $M$ is done through tokenization using a trained Byte Pair Encoding tokenizer [24] such that $C^{\prime}$ or $M\rightarrow s_{0},s_{1},...s_{T}$ , where $s_{i}\in\mathbb{V}$ and $\mathbb{V}$ is the vocabulary of the tokenizer. We use the same vocabulary for both $C^{\prime}$ and $M$ . These tokens are passed through an Embedding layer, which is shared across the encoder and decoder, to get the token’s vector representation, which will be updated progressive through various Attention and Feed Forward layers, we will explain further.  

The output $M$ is done in an autoregressive manner, where the output of one time step from the model is fed back into the decoder portion of the Transformer for generating the probability distribution of the next token. Formally, the probability distribution of token $y_{i}$ is conditioned on the output of the encoder $Z$ and the $y_{<i}$ previously generated tokens: $\begin{array}{r}{p(M)=\prod_{i}^{m}p(y_{i}|y_{<i},Z)}\end{array}$ .  

The Transformer architecture itself has no way of modeling sequential information. Therefore, sequential information is injected either at the bottom of the network (Fig. 1) or at each Transformer block of the network depending on the positional scheme. For our four positional schemes, only one injects the positional information at the bottom of the network, namely sinusoidal, the rest of the schemes inject the information at each Transformer block.  

The Transformer block’s composition depends on if it is part of the encoder or decoder. In the encoder portion, the attention is computed by transforming a given sequence, $s=(s_{1},s_{2},...,s_{n})$ where $s_{i}\in\mathbb{R}^{d_{s}}$ into a new sequence of the same size, $z=(z_{1},z_{2},...,z_{n})$ where $z_{i}\in\mathbb{R}^{d_{z}}$ via a weighted sum where the weight can be intuitively thought as the amount of attention to pay to the value of $s_{j}$ in the sequence. $\mathbb{R}^{d_{s}}$ represents the embedding space of the Embedding layer that transforms the discrete token into a continuous vector of size $d_{s}$ and similarly $\mathbb{R}^{d_{z}}$ represents the vector space that is composed of $d_{z}$ dimensions where $d_{z}$ can be the same or a different size than $d_{s}$ . The weighted sum can be represented as follows:  

$$
z_{i}=\sum_{j=1}^{n}a_{i j}(s_{j}W^{V})
$$  

With $W^{V}$ being a learned value weight matrix and $a_{i j}$ being calculated with the following softmax formula:  

$$
a_{i j}={\frac{\exp{e_{i j}}}{\sum_{k=1}^{n}\exp{e_{i k}}}}
$$  

And $e_{i j}$ being calculated by taking the corresponding $s_{i}$ and $s_{j}$ tokens and multiplying them by a learned query and key weight matrix, $W^{Q}$ and $W^{K}$ , to get the corresponding query and key vectors. These vectors are then put through a compatibility function, namely the scaled dot product:  

$$
e_{i j}=\frac{(s_{i}W^{Q})(s_{j}W^{K})^{T}}{\sqrt{d_{k}}}
$$  

As it can be seen, no positional information is present in these operations. So, the original Transformer injected positional information into the beginning of the network by adding a position vector to the token vector to encode this information for the rest of the network. Let us now discuss each positional encoding scheme.  

Sinusoidal: Sinusoidal is the original scheme proposed in the Transformer paper [12]. The information is added directly to the token embeddings at the beginning of the network. Concretely, the same dimension of the token embeddings is used for the position embedding and the sinusoidals switch between sine and cosine:  

$$
P E_{p o s,2i}=s i n(p o s/10,000^{2i/d_{m o d e l}})
$$  

$$
P E_{p o s,2i+1}=c o s(p o s/10,000^{2_{i}/d_{m o d e l}})
$$  

Where pos refers to the position in the sequence and $i$ refers to the specific dimension of the position embedding. The authors chose this scheme as they believed it would allow for the model to learn to use relative positions. However, this approach is generally considered an Absolute Positional Encoding (APE) scheme.  

xPOS: Sun et al. [21] extended work from $\mathrm{Su}$ et al. [23] which made the observation that the dot product between queries and keys are where information is shared between different tokens. Therefore, position information can also be added of the relative position between the different tokens. Specifically, Su et al. [23] wanted to find an operation that satisfies the following:  

$$
(f_{q}(x_{m},m),f_{k}(x_{n},n))=g(x_{m},x_{n},m-n)
$$  

Where functions $f_{q}$ and $f_{k}$ add this relative information to the token embeddings $x_{m}$ and $x_{n}$ . respectively. To accomplish this, the authors introduced Rotary, which uses rotations of the token embeddings based on their position so that the relative position of the tokens are preserved through this dot product. Namely, they define the function $g$ that satisfies this to be  

$$
g(x_{m},x_{n},m-n)=R e((W_{q}\cdot x_{m})(W_{k}\cdot x_{n})*e^{i(m-n)\theta})
$$  

where the function $R e$ takes only the real part of the complex number. This is specifically for the 2D case, however, this is generalizable to any dimension that the token embeddings belong to.  

For a complete discussion of the equations and their generalization, we refer readers to the original paper [23].  

Sun et al. [21] extended this approach to have similar extrapolation abilities of ALiBi, discussed below, while still having better performance. To accomplish this, the authors introduced the idea of attention resolution where a model’s attention should monotonically decrease as the pair wise distance between tokens increases, similar to ALiBi.  

To integrate this into the rotation matrix, they apply an exponential decay that adds this property. They show that this gives a good trade-off between the Rotary performance and ALiBi’s ability to extrapolate to longer than seen during training sequences. For our experiments with xPOS, we use the original implementation from Su et al. [23] for the encoder and the extension, xPOS, by Sun et al. [21] for the decoder since the extension is unable to be applied directly to an encoder.  

ALiBi: In ALiBi, the positional information is injected by modifying the equation above by adding a static bias:  

$$
e_{i j}=\frac{(s_{i}W^{Q})(s_{j}W^{K})^{T}}{\sqrt{d_{k}}}+m^{h}(j-i)
$$  

Where $m$ is a head-specific scalar that is selected before training. We use the same geometric series for initializing these $m$ values per head as in the original ALiBi paper, namely starting from $2^{\frac{-8}{n_{h e a d s}}}$ and using the same value as the ratio. Intuitively, this static bias penalizes query and key vectors that are far away from each other. Figure 2 visualizes this process. Specifically, it shows how queries and keys corresponding to the same token do not receive any reduction whereas mismatched queries and keys receive a reduction proportional to their relative distance.  

This process was originally designed for decoder-only Transformer models. However, since we use an encoderdecoder Transformer model, we additionally use the bidirectional version for the encoder portion as outlined in a post by the original author 1.  

T5: Similar to ALiBi, T5 introduces a bias inside the softmax equation that is based on distance. Specifically, this bias is a learned scalar that is added to the query and key dot product $(s_{i}W^{Q})(s_{j}W^{K})^{T}+b_{i j}^{h}$ where each attention head, $h$ , has a different learned bias. T5 introduces this idea of buckets, which are the different learned biases, where the different $i j$ pairs logarithmically map up to a relative position of 128 beyond which the same $i j$ pairs are mapped to the same bucket. After each attention operation in the encoder Transformer block follows a normalized residual connection, a simple Feed Forward Multi-Layer Perceptron, and another normalized residual connection. A similar process happens in the decoder block.  

However, there is an additional attention mechanism that happens after the normal self-attention is applied to the transformed output token embeddings, which considers the encoder’s representation of the input, $Z$ . This is known as crossattention and follows the same process as self-attention except the keys and values are constructed from the representation $Z$ while the query is built from the output representation. Intuitively, this can be thought of as the output tokens requesting specific information from the input tokens.  

# III. RELATED WORK  

We discuss the literature related to (i) code completion, (ii) techniques aimed at improving the generalizability of Transformers, and (iii) NLP studies aimed at investigating the extent to which Transformers can generalize to instances different from those seen during training.  

# A. Code Completion  

Code completion has been studied extensively for several years in SE [25], [26], [27], [28], [29], [30], [31], [32], [33], [34], [35], [36], [37], [38], [39], [40], [14], [2], [15], [16], [41], [42]. It has seen many iterations going from techniques able to generate simple predictions such as method calls [43] to recent DL models able to predict multiple code statements [14], [2], [16], [44], [42].  

Our work can be thought of as a research thrust continuation to that one of Ciniselli et al. [2]. In their work, they explored the applicability of Transformer models for the task of code completion, especially as the number of tokens to complete grows. They found a T5 architecture to perform fairly well on this task, reporting however a performance degradation as the number of tokens to predict grew. While Ciniselli et al. [2] study how a T5 model trained on a specific dataset can work with prediction tasks of different complexity, we study how models trained on different datasets featuring instances characterized by different lengths generalize to unseen lengths.  

Hendrycks et al. [45] and Chen et al. [14] proposed a systematic evaluation for code generation tools using functionalcorrectness. However, their focus was on generating complete programs rather than completing existing code.  

Fried et al. [16] investigated a novel infilling pretraining scheme for decoder-only Transformer architectures that allow them to use bidirectional context to complete code. They found this infilling scheme allows for models that achieve a higher code completion rate than left context only models for single and multi-line code completions. Our study is complementary to these since we focus on encoder-decoder models and on the generalization to code completion length, rather than general performance.  

# B. Methods to Improve Length Generalization  

There has been a plethora of literature on different techniques to improve generalization of inference length of Transformer models. Neishi and Yoshinaga [46] demonstrated that replacing the positional encoding scheme in Transformers with a Recurrent Neural Network (RNN) improves machine translation performance on sentences longer than those seen during training. In a similar vein, Dai et al. [19] take inspiration from RNNs by adding a segment-level recurrence mechanism to improve performance on long sequences. Dubois et al. [47] introduced a separate location and content based attention to improve generalization to longer sequences than those seen during training. Newman et al. [48] showed that training models to predict the end of sequence (EOS) token significantly degraded a model’s ability to generalize to longer sequences than those seen during training.  

Specifically, they found that the hidden states of models trained on predicting EOS tokens lead to stratification of the hidden state manifold by length and get clustered into length attractors, which are areas where the EOS token is given the highest-probability prediction. This causes a failure to generalize to longer sequences that are not present when omitting the prediction of the EOS token. Lastly, several works [49], [50], [18], [23], [21] introduced various modifications to the positional encoding schemes of Transformers to improve generalization to longer sequences not seen during training. Among those, we considered in our study the four described in Section II due their good representativeness of the different types of encoding schemas, namely Absolute Positional Encoding (APE) and Relative Positional Encoding (RPE). In addition, we considered the T5 model since Press et al. [18] also showed it had an ability to slightly generalize to longer sequence lengths than it had seen during training.  

# C. Evaluations of Length Generalization  

The most similar work to ours (from the NLP field) is Rosendahl et al. [51]’s study on analyzing a variety of positional encoding schemes and their ability to generalize to longer machine translation sentences than those seen during training. Similar to other works [46], [18], they found that relative positional encodings are superior to absolute positional encodings for generalizing to longer sequences. Lake and Baroni [52] and Hupkes et al. [53]’s work focused on measuring the composability of language models. One type of composition was specific to generalization of sequence length and they both found current language models to be unable to perform well on such tasks.  

# IV. EVALUATION DESIGN  

The goal of our study is to determine whether popular positional encoding schemes for length generalization work for the task of code completion. Namely, we seek to answer the following question:  

$\mathbf{R}\mathbf{Q}_{1}$ : To what extent can different positional encoding schemes generalize to different code lengths for the task of code completion?  

In the context of code completion this means studying whether models trained on completing code sequences having a specific length generalize when used to complete shorter/- longer sequences.  

This is analogous to whether models are able to utilize different amounts of information, in terms of the input tokens, as compared to what they have seen during training. Naturally, shorter instances require shorter training time. Yet, it is unclear if a model trained on short code completions can generalize to also work on longer ones and vice versa. While answering $\mathbf{RQ}_{1}$ we also check whether our findings generalize to multiple programming languages. In particular, we contextualize our study to Python and Java, as languages often adopted in code completion studies (see e.g., [2], [38]). Also, we consider two different code completion tasks recently used in the code completion study by Ciniselli et al. [2]: statement-level and block-level completion.  

The former is the classic code completion task in which the last $n$ tokens of a single code statement are masked, with the model in charge of predicting them. The latter, instead, possibly extends the completion to multiple statements, masking the last $n$ tokens in a block of code (e.g., the body of an if statement) and asking the model to guess them.  

In the following we detail the procedure used to (i) collect the training/testing datasets employed in our study (Section IV-A), and (ii) perform the required data collection and analysis (Section IV-B).  

# A. Dataset Construction  

To build the datasets needed for our study, we mined data from GitHub open source projects. In particular we: (i) used the GitHub search tool by Dabic´ et al. [54] to identify all Python and Java GitHub projects having at least 100 commits, 10 contributors, 10 stars and 10 issues (to exclude toy projects); (ii) sorted the projects by number of stars; (iii) cloned the top $3\mathbf{k}$ and extracted from each of them the functions in the master branch (to only rely on functions likely to be syntactically correct); (iv) removed all functions containing non-ascii characters (to avoid problems when reading data); (vi) removed all duplicates (to avoid leaking of information between the training, validation, and test sets we created out of this dataset); (vii) removed from the dataset all instances consisting of more than 1,024 tokens. The latter is a procedure usually adopted in applications of DL4SE (e.g., [4], [55], [6]). Indeed, too long instances make the training of DL models too expensive, also motivating our investigation into the length generalizability.  

Such a process resulted in the collection of $\mathord{\sim}4\ensuremath{\mathbf{M}}$ Python functions and ${\sim}4.5\mathrm{M}$ Java functions which we further processed to create datasets aimed at answering our RQ.  

1) Java dataset: statement-level code completion task: The Java dataset will cover the statement-level code completion task. The goal is to build three datasets featuring instances (i.e., functions) having different lengths, namely short, medium, and long instances. Basically, with “length” we refer to the number of input tokens provided to the model. In all three datasets we keep constant the complexity of the prediction to generate (i.e., the number of masked tokens). Indeed, only in this way we can “isolate” the impact on performance of changing the input length.  

Since the code completion task, which we are focusing on, requires the masking of code statements, we start by removing for the set of collected Java functions all of those that do not contain any statements. We also removed all Javadoc comments, since we are focusing on completion tasks within the body of a function. We then compute the number of Java tokens within each of the remaining 3,833,445 functions: this results in a distribution of functions’ length.  

We then compute a second distribution representing the number of Java tokens within the code statements in the subject functions, observing a median of 11 tokens per statement. The idea is to mask in each instance of the three datasets we will create (i.e., short, medium, long) the exact same number of tokens (11).  

As previously mentioned, this is done to keep constant the “complexity” of the completion task and better isolate the impact of the sequence length on the observed performance.  

Given such a constraint, we remove all the functions not containing any valid statements to mask, i.e., a statements consisting of at least 11 Java tokens. We sort the remaining 1,855,578 functions by their length and split them into three sets of the same size, obtaining: (i) a first set of functions with lengths ranging from 6 to 96 (short dataset); (ii) a second set of functions with lengths ranging from 97 to 180 (medium); and (iii) a third set of functions with lengths ranging from 181 to 1024 (long).  

For each function $F$ in each of the three datasets, we created $n$ training instances, where $n$ is the number of valid statements to mask $F$ contains (i.e., the statements having at least 11 tokens). This may end up in generating duplicates due to different functions from which we masked the only part being different, thus resulting in duplicates. For this reason, we perform a second deduplication round on all the datasets.  

The final set of (masked) functions is then flattened to obtain the model input by replacing all new line characters $(i.e.,\ \cdot\backslash\mathrm{n^{\prime}})$ with a special tag, $\langle\mathrm{NEW\_LINE}\rangle$ , and remove all tabs (i.e., $\cdot\langle\t^{\prime}\rangle$ and white spaces used to indent the code. We randomly split each set (short, medium, long) into training $(80\%)$ , validation $(10\%)$ and test $(10\%)$ by making sure that all the instances obtained from the same function fall into the same set.  

Finally, for each of the three datasets (short, medium, long), we limit the number of training instances to $280\mathrm{k}$ and, proportionally, those of the test and evaluation set to $35\mathrm{k}$ . This is done to reduce the training cost of our study, as explained later, required to train and test $32~\mathrm{DL}$ models. These numbers (i.e., 280k and 35k) are inherited from the (smaller) Python dataset that we will describe in the next section. In other words, we aligned the size of the Java and of the Python datasets towards the smallest one (Python), due to our computational resources.  

To summarize, at the end of this process we have three datasets (short, medium, and long) each split into training, validation, and test, all containing the same number of instances having, however, different lengths.  

We also built a fourth dataset, named mixed, consisting of a mix of the three lengths: 1/3 of instances comes from the short dataset, 1/3 from the medium, and $1/3$ from the long. In this case we only built the training and the validation sets, since we will test the model trained on the mixed dataset on the short, medium and long test sets.  

2) Python dataset: block-level code completion task: Similarly to what we discussed for Java, we build three Python datasets (short, medium, and long) featuring instances (functions) having different lengths but characterized by the same task complexity (i.e., same number of masked tokens to predict). The main difference between the Java and the Python dataset is that the latter simulates block-level completion, thus possibly featuring completions spanning across multiple statements. The process used to build the Python datasets resembles the one we presented for Java. Thus, we only briefly summarize it here. We removed all functions not containing any code block (2,833,017). For consistency with the Java datasets, we decided to keep the same task complexity, meaning that we target the masking of the last 11 Python tokens within a given block. Thus, we remove from the dataset all functions not containing any valid block to mask (i.e., a block consisting of at least 11 tokens).  

We then sort the remaining functions by their length and split them into three sets of the same size: short (featuring functions with length from 30 to 150), medium (from 151 to 309), and long (from 310 to 1024). For each function $F$ we created $n$ instances, each one having a different block featuring its last 11 tokens masked. For the same reasons previously explained, we remove any duplicates created at this stage.  

We replace all characters used to indent the code (i.e., $\mathbf{\hat{\theta}}\langle\mathrm{n}^{\prime},\mathbf{\hat{\theta}}\rangle\mathrm{t}^{\prime}$ and extra white spaces) with a special tag: 〈TAB〉. This allows to flatten each function without losing information about the indentation, which is fundamental for the Python syntax.  

Finally, we split each dataset (short, medium, long) into training, validation, and test using the same procedure described for Java. For each dataset, the training contains $280\mathrm{k}$ instances, while the evaluation and test contain $35\mathrm{k}$ instances. These numbers have been dictated by the smallest dataset involved in our study, being the short Python dataset. Aligning the size of all datasets removes another possible confounding factor.  

# B. Data Collection & Analysis  

To answer our research question, we train eight models (four per each of the subject languages, namely Python and Java) for each of the four experimented position encoding schemes (i.e., Sinusoidal, xPOS, ALiBi, and T5). This leads to a total of 32 trained models. The four models for each language have been trained on datasets featuring code completions having inputs (i.e., the Java or Python function to complete) characterized by different lengths (i.e., short, medium, long, and mix). Then, each of these models have been used to generate predictions on three test sets featuring code completions of different lengths (i.e., short, medium, and long).  

TABLE I HYPERPARAMETERS USED AND SEARCHED.   

![](images/73caef0dd4a4984915be9586b64f218dd55801fa3913281665a836d69195ebd3.jpg)  

This allows us to verify if, for example, a model trained on short code completions can generalize to a test set containing long instances. Also, we can verify whether a model trained on code completions having a mixture of lengths (i.e., featuring short, medium, and long sequences) can achieve on each of the three test sets (i.e., short, medium, and long) results competitive with those of models specialized (i.e., trained only) on instances having a specific length. For example, we can check whether the model trained on the mixture of lengths achieves on the short test set performance comparable to those of the model trained on the short training set. Remember that the amount of instances in each training set is fixed. Thus, observed differences should be due to the length of the employed training instances.  

To reduce confounding factors, we used the same hyperparameters amongst all 32 models. The adopted hyperparameters are those suggested in the paper originally proposing the Transformer architecture [12] and are reported in Table I. This design decision also avoided the need for an expensive hyperparameters tuning involving 32 different models.  

All models have been trained with the Adam optimizer [56] with a cosine learning rate scheduler using a warmup of 2,000 steps. We used a vocabulary size of $50\mathrm{k}$ for the tokenizer, which was shared across all the models.  

For implementing and training the Transformers, we used x-transformers [57] and Pytorch Lightning [58]. Additionally, when generating samples, we used Nucleus Sampling [59] with a $t o p_{p}=0.95$ and stopped generations once the 〈EOS〉 token was produced or the maximum number of tokens, 128, were produced. We trained all models for a maximum of five epochs and used the best performing checkpoint based on validation loss, which happened to always be the models trained on all five epochs. While this suggests that better performance might be obtained with additional training epochs, it is important to note that our goal is not to train the most performant code completion model, but rather to show that, given a certain training cost, the consistency of training and test data (in terms of predictions length) substantially impacts performance at inference time.  

To assess the performance of the models on the test sets, we collect the predictions they generate and measure the percentage of Exact Match (EM) with respect to the expected target. An EM indicates that the code generated by the model for the completion instance is identical to the target.  

We also compute metrics usually adopted in the assessment of generative models, namely the BLEU [60], ChrF [61], Levenshtein Distance [62], ROUGE [63], and METEOR [64] score with respect to the target.  

BLEU is a popular automatic metric for machine translation tasks due to the high correlation to human judgement. It has become a standard metric in code completion tasks [65] since it measures the overlap of a predicted sequence and a set of reference sequences in terms of n-grams. ChrF is a character level metric which averages the F-score of 1 to 6- grams of characters. Levenshtein Distance is a measure of the minimal edit operations (i.e., insert, modify, and remove), that would be needed to convert the predicted sequence into the target one, and it has been used in assessing the models’ performance in previous code completion studies [2]. ROUGE, and specifically RougeL, is a metric that measures the longest common subsequence between the predicted and ground truth sequences. Lastly, Meteor is also an F-score, where the recall is weighted nine times more than the precision.  

Additionally, predictions are penalized for not having adjacent unigrams that exist in the ground truth. We also measure the Cross-Entropy of the generated predictions (i.e., a measure of the surprise of the model when predicting the ground truth sequence).  

While we computed all the above-described metrics, we only discuss the results achieved in terms of EM, ChrF, and RougeL. The former (EM) is an easy-to-interpret proxy of the model’s performance. ChrF and RougeL, instead, have been found to be best at measuring performance compared to human evaluation and allow to claim significance $95\%$ confidence) if the difference between two models on code generation tasks is greater than two points [66]. Our full analysis can be found in our replication package [67]. For implementing these metrics, we used the Huggingface’s datasets library [68], which contains a large selection of automated metrics for the evaluation of generative models.  

# V. RESULTS DISCUSSION  

Tables II, III, and IV show the results in terms of EM, ChrF, and RougeL, respectively, achieved by the four positional encoding schemes when trained on datasets featuring code completions of different lengths (columns) and tested on the short, medium, and long test sets (rows). The results are reported for both Java and Python. To provide a concrete example, let us consider the EM results reported in the Table II. Here, the Sinusoidal schema trained on short Java completions generated $10.81\%$ EM predictions when tested on short instances (i.e., those resembling the training instances).  

Instead, when the training is performed on instances having a medium length, the percentage of EM predictions drops, on the same short test set, to $2.91\%$ , finally falling at $0.50\%$ when the training was performed on long instances.  

Similar results are observed for Python in which, however, the percentage of EM predictions is lower, moving from $1.57\%$ achieved on the short test set when training on short instances down to the $0.03\%$ when tested on the long ones.  

Tables II, III, and IV also contain two “Avg. $\Delta^{\prime\prime}$ columns (one per language). Given a row in one of the tables (e.g., the first row in Table II reporting the performance of the Sinusoidal schema when run on the short test set), the Avg. $\Delta$ indicates the relative change in performance observed, on average, for the models trained on different lengths (in our example, those trained on medium and long completions) when compared the one specialized on lengths related to that row (i.e., short). Indeed, the $84.22\%$ shown as average $\Delta$ in the subject row is the result of:  

$$
\frac{\frac{10.81\%-2.91\%}{10.81\%}+\frac{10.81\%-0.50\%}{10.81}}{2}=84.22\%
$$  

where $10.81\%$ is the percentage of EM predictions for Java generated by the Sinusoidal schema when trained and tested on code completions of short length, while $2.91\%$ and $0.50\%$ are the EM scores achieved by the Sinusoidal schema when trained on medium and long instances, respectively, while still being tested on short instances.  

Finally, Tables II, III, and IV adopt three styles to highlight findings in the context of a specific test set length. Let us focus on the Java results achieved on the short test set in terms of EM (Table II). The black box shows the bestperforming combination of encoding schema, training length for such a test set (i.e., T5 trained on short completions). The bold values highlight, for each encoding schema, the bestperforming training length for such a test set (i.e., in all cases, training on short instances works better when testing on short instances). The red value in each “Avg. ∆” column highlights, instead, the encoding schema manifesting the lowest relative drop in performances when moving from a training length matching the instances in the test set (e.g., training on short, testing on short) to the other training lengths. In this case, the lowest relative drop in terms of EM predictions is exhibited by xPOS. Note that a lowest relative drop indicates a better ability of the encoding schema to generalize to unseen lengths.  

The first observation that can be made from the three tables is that T5’s positional encoding schema performs better than all other approaches. Such a finding is consistently captured by all metrics, including ChfR and RougeL for which the difference is always substantially higher than two points, indicating a statistically significant difference at $95\%$ confidence [66]. Being the best performing one, however, does not save T5 from a strong general observation that can be made across the board for all training schemes: They all suffer from a major degradation in performance when applied on code completions having a length different from the one they have been trained on. Interestingly, the degradation is not only observed when the models are tested on instances being longer (likely more complex to handle) than those they have been trained on, but also in the opposite direction. This can be easily seen in Tables II, III, and IV by the fact that (i) the average $\Delta$ values are always positive, and (ii) the bold values in a given test set length are always associated with the same length in the training set.  

TABLE II EXACT MATCH SCORE ( ) ACHIEVED BY THE DIFFERENT POSITION ENCODING SCHEMES.   

![](images/cc446098dc3edd76994352e3fb0cb0e5ec66fb1b440f0246770c3c0f4197788f.jpg)  

TABLE III CHRF SCORE ( ) ACHIEVED BY THE DIFFERENT POSITION ENCODING SCHEMES.   

![](images/6966d36bdc3d5a163bd0eaeeb46f787202fba5fd0e13e1d3bd3039d22e994895.jpg)  

TABLE IV ROUGE-L SCORE ( ) ACHIEVED BY THE DIFFERENT POSITION ENCODING SCHEMES.   

![](images/3317b94c2a4329fca26f2e6b201b89951c5e6a23bfb0262083e0e8de084ef5a8.jpg)  

The second observation concerns the encoding schema reporting the lowest average drop in performance (red values in the “Avg. $\Delta^{\prime\prime}$ column in the three tables). Overall, also from this perspective, T5 seems to be the best choice. There are a few exceptions to this trend, depending on the test set under analysis and on the metric used as proxy for performance.  

For example, on the short Java test set, T5 is the second best in class in terms of EM and ChfR score, while confirming its leadership when looking at the RougeL score. By considering all 18 combinations of test set length (3), language (2), and evaluation metrics (3), T5 is the one exhibiting the lowest relative drop in 11 $(61\%)$ of cases, and the second-best in additional 3 cases $(17\%)$ . Still, as observed, T5 also exhibits major drops in performance when working on sequence lengths unseen during training. For example, there is an absolute drop of $13.41\%$ in terms of EM predictions when testing T5 on the long dataset when trained on short sequences as compared to the one trained on long sequences $17.03\%$ vs $3.62\%$ ). The trend is confirmed when looking at the ChfR and the RougeL scores.  

xPOS is the second best performing schema, both in terms of absolute performance and generalization to different lengths. ALiBi and Sonusoidal follow, exhibiting similar performances from both perspectives.  

Take Away #1: T5’s positional encoding scheme achieves the best overall performance across metrics, lengths, and languages. Also, it is also better at generalizing to unseen lengths. In general, however, all encoding schemes suffer generalization issues for unseen lengths.  

Differences across languages. Overall, our main findings hold on both languages. These include: (i) the lack of generalizability to unseen lengths of any of the experimented encoding schemes; and (ii) the superiority of T5 both in terms of absolute performance and relative drop when dealing with unseen lengths.  

We do not compare the performance achieved on the two languages since (i) the test sets are different, (ii) the code completion tasks are different (statement-level vs. block-level), and (iii) the syntaxt of the two languages makes the prediction tasks quite different, since Python requires the generation of the ${<}\mathrm{T}\mathrm{AB}>$ indentation tokens while Java does not.  

Take Away #2: On both languages, all encoding schemes struggle to generalize to unseen lengths. T5 confirms its superiority on both Java and Python code.  

Impact of training diversity. Tables V (EM), VI (ChrF), and VII (RougeL) report the results achieved by the four encoding schemas (rows) when trained on the mix dataset (i.e., the one featuring a mixture of instances taken from the short, medium, and long datasets) and tested on the three datasets featuring sequences of different length (columns). Note that the mix training dataset has exactly the same number of instances of the other length-specific datasets, thus do not introducing a confounding variable related to the training size.  

The $\Delta$ associated to each combination of encoding schema and test set is the relative change in performance with respect to the same schema exclusively trained for sequences of the corresponding length. For example, in terms of ChrF score (Table VI), T5 trained on short Java sequences achieves a $42.97\%$ ChrF score when tested on the short dataset. Such a score grows to $45.47\%$ when T5 is trained on the mix dataset, with a relative improvement equal to $45.47\%$ - $42.97\%)/42.97\%=+5.82\%$ . The achieved findings confirm the superiority of T5 in this scenario as well.  

Most importantly, we found that relying on a mixture of lengths during training is generally sufficient to achieve results approaching, and in some cases improving, than those achieved by specifically training the model for the target sequence length. Indeed, by comparing the relative $\Delta$ reported, for example, in Table VI (ChfR scores when training on the mix dataset) to those reported in Table III (ChfR scores when training on datasets featuring functions having different lengths), it is possible to observe a major difference in terms of magnitude of the deltas, with those in VI being substantially smaller.  

This indicates that, while in some cases training on a specific length range $l$ could help in achieving better performances on test instances fitting $l$ , training on a mixture of lengths is a safe choice, since it would not result in dramatic lost of performances as those observed in Table III.  

Finally, it is worth mentioning that while training diversity was very successful in Java, it helped less in Python. Still, when comparing the deltas in performance between Tables II, III, IV (i.e., the delta in performance when testing on prediction lengths different from the one the model has been trained for vs testing on the same prediction length) with the deltas in Tables V, III, and VII (i.e., the delta in performance when exploiting training diversity vs when training on the same prediction length used for testing) it can be seen that even for Python training diversity substantially helped.  

Take Away #3: Training on a mixture of lengths being representative of those that will be seen during testing but also including other types of lengths might be the safest choice in most of cases. Only in scenarios in which even minor increases in performance are considered valuable, experimenting with a combination of models specialized on different lengths might be worthwhile, to then decide the best strategy to adopt.  

# VI. THREATS TO VALIDITY & FUTURE WORK  

Threats to Internal Validity. In order to control for various levels of bias that can creep into our evaluation, we ensured to hold as many variables as possible in our datasets and models constant. This involved ensuring that there were no duplicates across the different training splits, both in the input and target [69]. Also, we held constant the hyperparameters across our different models and only changed the type of length they were trained on. However, despite these thorough mitigation strategies, bias can still be present in our empirical study.  

Threats to Construct Validity. To mitigate threats to construct validity, we calculated a range of different metrics that have been commonly used in code completion literature. Additionally, we focus our discussion either on metrics that have been shown to correlate with human preference and that are more statistically stable [66] (i.e., ChfR and RougeL) or that allow for a simple interpretation such as EM.  

While there have been new recent metrics that are specific to code data for code completion, namely CodeBLEU [70] and functional-correctness [45], [14], we did not compute these for the following reasons. CodeBLEU has been shown to be not as stable as ChrF and RougeL [66]. Unfortunately, functionalcorrectness was not even an option for our evaluation due to the lack of unit tests for our test examples.  

Besides the metric used, the type of code completion performed can result in bias as there has been some studies showing that synthetic benchmarks of code completion where the completions are randomized do not necessarily reflect the performance of real-world code completions [27].  

TABLE V EXACT MATCH MIX ( ) ACHIEVED BY THE DIFFERENT POSITION ENCODING SCHEMES.   

![](images/6e30a45a5a2e02f626efd2a6bda514f8b6ecf8c7c679ae94f154de81e462fb85.jpg)  

TABLE VI CHRF MIX ( ) ACHIEVED BY THE DIFFERENT POSITION ENCODING SCHEMES.   

![](images/09d4458f219ad92bf22c97856adc0125e5e0c36c0055750644745386bf5a0b3b.jpg)  

TABLE VII ROUGE-L MIX ( ) ACHIEVED BY THE DIFFERENT POSITION ENCODING SCHEMES.   

![](images/e57d56f9e3be0c6ec04558b8efa746727df597b39423556cd56fed5655ebd3a3.jpg)  

Threats to External Validity. We investigated two Transformer architectures to mitigate the threats to external validity. Additionally, we measured multiple types of metrics and constructed our datasets in such a way as to hopefully mimic realistic code completion scenarios. Additionally, we used two popular programming languages, namely Java and Python, to better ensure our results generalize across languages.  

# VII. CONCLUSION  

In this paper, we explored the generalization ability of popular decoder-only Transformer position encoding schemes that have shown success in Natural Language Processing that can be extended to the encoder-decoder Transformer and code completion task. Specifically, we investigated four different positional encoding schemes, namely Sinusoidal [12], xPOS [23], [21], ALiBi [18], and T5 [20], which have been proposed as a way to boost this generalization ability and represent the most popular position encoding types, i.e., Absolute Positional Encoding and Relative Positional Encoding.  

Overall, our results demonstrate that none of the studied positional encoding schemes has the ability to generalize to unseen lengths.  

While these findings suggest that there are currently no “shortcuts” for researchers or developers of tools utilizing these models to efficiently train on short lengths (which are less expensive to process) and generalize to longer lengths, it is interesting to note that training on a mixture of lengths should represent a safe compromise in most of cases.  

Still, the possible drop in performance this may result in should be considered and assessed case by case, depending on the context in which the models must be used, the targeted programming language, and the actual focus on performance.  

Moreover, it is worth considering that our conclusions are only based on performance proxies we adopted (i.e., EM, ChrF, and RougeL). Different trade-offs come into play if best performance is not the only constraint. For example, while T5 is the best performing positional encoding, it is also the slowest and most memory intensive both for training and inference. Therefore, in performance-critical settings it might be more beneficial to use xPOS, which achieves less performance, but is more efficient. Similar observations can be made for the Sinusoidal and ALiBi schemes for which, however, the cost to pay in terms of performance as compared to T5 is higher.  

Lastly, given our findings and the potential impact that the generalizability of code completions models can have on the software engineering community in terms of training efficiency, we believe future research should explicitly target this problem with research focused outside of different positional encoding schemes and possibly involving additional architectural changes to the Transformer or even proposing completely novel architectures.  

Also, we plan to run similar studies on other code-related tasks, such as code summarization.  

# DATA AVAILABILITY  

Our datasets, code, models, are available in our reproduction package [67]. It contains all of our additional results that were excluded due to space constraints. Specifically, additional metrics, i.e., BLEU, Levenshtein Distance, Meteor, and Cross Entropy, that follow similar trends as the ones discussed in this paper.  

Additionally, we provide all checkpoints for each of our evaluated models, i.e., Sinusoidal, xPOS, ALiBi, and T5, licensed under Apache 2.0. The code repository contains all the code, also released under the same license, for reproducing our results along with documentation on the process required to do so. Lastly, the processed datasets are also released under a creative commons license. We hope that the availability of such code and data can help in fostering more research in this area.  

# ACKNOWLEDGMENT  

This project has received funding from the European Research Council (ERC) under the European Union’s Horizon 2020 research and innovation programme (grant agreement No. 851720). The researchers from W&M have been supported in part by the NSF CCF-2311469 and CNS-2132281. We also acknowledge support from Cisco Systems. Any opinions, findings, and conclusions expressed herein are the authors’ and do not necessarily reflect those of the sponsors.  

# REFERENCES  

[1] M. White, C. Vendome, M. Linares-Vasquez, and D. Poshyvanyk, “Toward deep learning software repositories,” in 2015 IEEE/ACM 12th Working Conference on Mining Software Repositories, 2015, pp. 334– 345.   
[2] M. Ciniselli, N. Cooper, L. Pascarella, A. Mastropaolo, E. Aghajani, D. Poshyvanyk, M. Di Penta, and G. Bavota, “An empirical study on the usage of transformer models for code completion,” IEEE Transactions on Software Engineering, 2021.   
[3] R. Tufano, S. Masiero, A. Mastropaolo, L. Pascarella, D. Poshyvanyk, and G. Bavota, “Using pre-trained models to boost code review automation,” in 2022 IEEE/ACM 44th International Conference on Software Engineering (ICSE), 2022, pp. 2291–2302.   
[4] A. LeClair and C. McMillan, “Recommendations for datasets for source code summarization,” in Proceedings of the 2019 Conference of the North American Chapter of the Association for Computational Linguistics: Human Language Technologies, Volume 1 (Long and Short Papers), Jun. 2019, pp. 3931–3937.   
[5] M. Tufano, C. Watson, G. Bavota, M. D. Penta, M. White, and D. Poshyvanyk, “An Empirical Study on Learning Bug-Fixing Patches in the Wild via Neural Machine Translation,” ACM Transactions on Software Engineering and Methodology, vol. 28, no. 4, pp. 1–29, 2019. [6] Z. Chen, S. Kommrusch, M. Tufano, L. Pouchet, D. Poshyvanyk, and M. Monperrus, “Sequencer: Sequence-to-sequence learning for end-toend program repair,” CoRR, vol. abs/1901.01808, 2019. [7] C. Watson, M. Tufano, K. Moran, G. Bavota, and D. Poshyvanyk, “On learning meaningful assert statements for unit test cases,” in 2020 IEEE/ACM 42nd International Conference on Software Engineering (ICSE), 2020, pp. 1398–1409. [8] M. Tufano, C. Watson, G. Bavota, M. Di Penta, M. White, and D. Poshyvanyk, “Learning how to mutate source code from bug-fixes,” in 2019 IEEE International Conference on Software Maintenance and Evolution (ICSME), 2019, pp. 301–312. [9] C. Watson, N. Cooper, D. N. Palacio, K. Moran, and D. Poshyvanyk, “A systematic literature review on the use of deep learning in software engineering research,” ACM Transactions on Software Engineering and Methodology (TOSEM), vol. 31, no. 2, pp. 1–58, 2022.   
[10] A. Mastropaolo, N. Cooper, D. N. Palacio, S. Scalabrino, D. Poshyvanyk, R. Oliveto, and G. Bavota, “Using transfer learning for coderelated tasks,” IEEE Transactions on Software Engineering, pp. 1–20, 2022.   
[11] M. Tufano, J. Pantiuchina, C. Watson, G. Bavota, and D. Poshyvanyk, “On learning meaningful code changes via neural machine translation,” in 2019 IEEE/ACM 41st International Conference on Software Engineering (ICSE), 2019, pp. 25–36.   
[12] A. Vaswani, N. Shazeer, N. Parmar, J. Uszkoreit, L. Jones, A. N. Gomez, Ł. Kaiser, and I. Polosukhin, “Attention is all you need,” Advances in neural information processing systems, vol. 30, 2017.   
[13] D. E. Rumelhart, G. E. Hinton, and R. J. Williams, “Learning internal representations by error propagation,” California Univ San Diego La Jolla Inst for Cognitive Science, Tech. Rep., 1985.   
[14] M. Chen, J. Tworek, H. Jun, Q. Yuan, H. P. d. O. Pinto, J. Kaplan, H. Edwards, Y. Burda, N. Joseph, G. Brockman et al., “Evaluating large language models trained on code,” arXiv preprint arXiv:2107.03374, 2021.   
[15] J. Austin, A. Odena, M. Nye, M. Bosma, H. Michalewski, D. Dohan, E. Jiang, C. Cai, M. Terry, Q. Le et al., “Program synthesis with large language models,” arXiv preprint arXiv:2108.07732, 2021.   
[16] D. Fried, A. Aghajanyan, J. Lin, S. Wang, E. Wallace, F. Shi, R. Zhong, W.-t. Yih, L. Zettlemoyer, and M. Lewis, “Incoder: A generative model for code infilling and synthesis,” arXiv preprint arXiv:2204.05999, 2022.   
[17] O. Press, N. A. Smith, and M. Lewis, “Shortformer: Better language modeling using shorter inputs,” arXiv preprint arXiv:2012.15832, 2020.   
[18] O. Press, N. Smith, and M. Lewis, “Train short, test long: Attention with linear biases enables input length extrapolation,” in International Conference on Learning Representations, 2022. [Online]. Available: https://openreview.net/forum?id=R8sQPpGCv0   
[19] Z. Dai, Z. Yang, Y. Yang, J. Carbonell, Q. V. Le, and R. Salakhutdinov, “Transformer-xl: Attentive language models beyond a fixed-length context,” arXiv preprint arXiv:1901.02860, 2019.   
[20] C. Raffel, N. Shazeer, A. Roberts, K. Lee, S. Narang, M. Matena, Y. Zhou, W. Li, P. J. Liu et al., “Exploring the limits of transfer learning with a unified text-to-text transformer.” J. Mach. Learn. Res., vol. 21, no. 140, pp. 1–67, 2020.   
[21] Y. Sun, L. Dong, B. Patra, S. Ma, S. Huang, A. Benhaim, V. Chaudhary, X. Song, and F. Wei, “A length-extrapolatable transformer,” arXiv preprint arXiv:2212.10554, 2022.   
[22] GitHub, “Github copilot your ai pair programmer,” 2023. [Online]. Available: https://copilot.github.com/   
[23] J. Su, Y. Lu, S. Pan, A. Murtadha, B. Wen, and Y. Liu, “Roformer: Enhanced transformer with rotary position embedding,” arXiv preprint arXiv:2104.09864, 2021.   
[24] R. Sennrich, B. Haddow, and A. Birch, “Neural machine translation of rare words with subword units,” arXiv preprint arXiv:1508.07909, 2015.   
[25] A. Hindle, E. T. Barr, M. Gabel, Z. Su, and P. Devanbu, “On the naturalness of software,” Communications of the ACM, vol. 59, no. 5, pp. 122–131, 2016.   
[26] Z. Tu, Z. Su, and P. Devanbu, “On the localness of software,” in Proceedings of the 22nd ACM SIGSOFT International Symposium on Foundations of Software Engineering, 2014, pp. 269–280.   
[27] V. J. Hellendoorn, S. Proksch, H. C. Gall, and A. Bacchelli, “When code completion fails: A case study on real-world completions,” in 2019 IEEE/ACM 41st International Conference on Software Engineering (ICSE). IEEE, 2019, pp. 960–970.   
[28] V. Raychev, M. Vechev, and E. Yahav, “Code completion with statistical language models,” in Proceedings of the 35th ACM SIGPLAN Conference on Programming Language Design and Implementation, 2014, pp. 419–428.   
[29] M. Bruch, M. Monperrus, and M. Mezini, “Learning from examples to improve code completion systems,” in Proceedings of the 7th joint meeting of the European software engineering conference and the ACM SIGSOFT symposium on the foundations of software engineering, 2009, pp. 213–222.   
[30] X. Jin and F. Servant, “The hidden cost of code completion: Understanding the impact of the recommendation-list length on its efficiency,” in Proceedings of the 15th International Conference on Mining Software Repositories, 2018, pp. 70–73.   
[31] M. Izadi, R. Gismondi, and G. Gousios, “Codefill: Multi-token code completion by jointly learning from structure and naming sequences,” arXiv preprint arXiv:2202.06689, 2022.   
[32] G. A. Aye, S. Kim, and H. Li, “Learning autocompletion from realworld datasets,” in 2021 IEEE/ACM 43rd International Conference on Software Engineering: Software Engineering in Practice (ICSE-SEIP). IEEE, 2021, pp. 131–139.   
[33] V. J. Hellendoorn and P. Devanbu, “Are deep neural networks the best choice for modeling source code?” in Proceedings of the 2017 11th Joint Meeting on Foundations of Software Engineering, 2017, pp. 763–773.   
[34] D. Hou and D. M. Pletcher, “Towards a better code completion system by api grouping, filtering, and popularity-based ranking,” in Proceedings of the 2nd International Workshop on Recommendation Systems for Software Engineering, 2010, pp. 26–30.   
[35] S. Nguyen, T. Nguyen, Y. Li, and S. Wang, “Combining program analysis and statistical language model for code statement completion,” in 2019 34th IEEE/ACM International Conference on Automated Software Engineering (ASE). IEEE, 2019, pp. 710–721.   
[36] R. Robbes and M. Lanza, “How program history can improve code completion,” in 2008 23rd IEEE/ACM International Conference on Automated Software Engineering. IEEE, 2008, pp. 317–326.   
[37] , “Improving code completion with program history,” Automated Software Engineering, vol. 17, no. 2, pp. 181–212, 2010.   
[38] A. Svyatkovskiy, S. Lee, A. Hadjitofi, M. Riechert, J. V. Franco, and M. Allamanis, “Fast and memory-efficient neural code completion,” in 2021 IEEE/ACM 18th International Conference on Mining Software Repositories (MSR). IEEE, 2021, pp. 329–340.   
[39] A. Svyatkovskiy, Y. Zhao, S. Fu, and N. Sundaresan, “Pythia: Aiassisted code completion system,” in Proceedings of the 25th ACM SIGKDD International Conference on Knowledge Discovery & Data Mining, 2019, pp. 2727–2735.   
[40] Y. Yang, Y. Jiang, M. Gu, J. Sun, J. Gao, and H. Liu, “A language model for statements of software code,” in 2017 32nd IEEE/ACM International Conference on Automated Software Engineering (ASE). IEEE, 2017, pp. 682–687.   
[41] E. Nijkamp, B. Pang, H. Hayashi, L. Tu, H. Wang, Y. Zhou, S. Savarese, and C. Xiong, “Codegen: An open large language model for code with multi-turn program synthesis,” arXiv preprint arXiv:2203.13474, 2022.   
[42] L. B. Allal, R. Li, D. Kocetkov, C. Mou, C. Akiki, C. M. Ferrandis, N. Muennighoff, M. Mishra, A. Gu, M. Dey et al., “Santacoder: don’t reach for the stars!” arXiv preprint arXiv:2301.03988, 2023.   
[43] D. Mandelin, L. Xu, R. Bodı´k, and D. Kimelman, “Jungloid mining: helping to navigate the api jungle,” ACM Sigplan Notices, vol. 40, no. 6, pp. 48–61, 2005.   
[44] E. Nijkamp, B. Pang, H. Hayashi, L. Tu, H. Wang, Y. Zhou, S. Savarese, and C. Xiong, “Codegen: An open large language model for code with multi-turn program synthesis,” in The Eleventh International Conference on Learning Representations, 2023. [Online]. Available: https://openreview.net/forum?id=iaYcJKpY2B   
[45] D. Hendrycks, S. Basart, S. Kadavath, M. Mazeika, A. Arora, E. Guo, C. Burns, S. Puranik, H. He, D. Song et al., “Measuring coding challenge competence with apps,” arXiv preprint arXiv:2105.09938, 2021.   
[46] M. Neishi and N. Yoshinaga, “On the relation between position information and sentence length in neural machine translation,” in Proceedings of the 23rd Conference on Computational Natural Language Learning (CoNLL), 2019, pp. 328–338.   
[47] Y. Dubois, G. Dagan, D. Hupkes, and E. Bruni, “Location Attention for Extrapolation to Longer Sequences,” in Proceedings of the 58th Annual Meeting of the Association for Computational Linguistics. Online: Association for Computational Linguistics, Jul. 2020, pp. 403–413. [Online]. Available: https://www.aclweb.org/anthology/2020. acl-main.39   
[48] B. Newman, J. Hewitt, P. Liang, and C. D. Manning, “The eos decision and length extrapolation,” arXiv preprint arXiv:2010.07174, 2020.   
[49] S. Kiyono, S. Kobayashi, J. Suzuki, and K. Inui, “Shape: Shifted absolute position embedding for transformers,” arXiv preprint arXiv:2109.05644, 2021.   
[50] T. Likhomanenko, Q. Xu, G. Synnaeve, R. Collobert, and A. Rogozhnikov, “Cape: Encoding relative positions with continuous augmented positional embeddings,” Advances in Neural Information Processing Systems, vol. 34, pp. 16 079–16 092, 2021.   
[51] J. Rosendahl, V. A. K. Tran, W. Wang, and H. Ney, “Analysis of positional encodings for neural machine translation,” in Proceedings of the 16th International Conference on Spoken Language Translation, 2019.   
[52] B. Lake and M. Baroni, “Generalization without systematicity: On the compositional skills of sequence-to-sequence recurrent networks,” in International conference on machine learning. PMLR, 2018, pp. 2873– 2882.   
[53] D. Hupkes, V. Dankers, M. Mul, and E. Bruni, “Compositionality decomposed: How do neural networks generalise?” Journal of Artificial Intelligence Research, vol. 67, pp. 757–795, 2020.   
[54] O. Dabic, E. Aghajani, and G. Bavota, “Sampling projects in github for MSR studies,” in 18th IEEE/ACM International Conference on Mining Software Repositories, MSR 2021. IEEE, 2021, pp. 560–564.   
[55] M. Tufano, D. Drain, A. Svyatkovskiy, S. K. Deng, and N. Sundaresan, “Unit test case generation with transformers,” CoRR, vol. abs/2009.05617, 2020. [Online]. Available: https://arxiv.org/abs/2009.05617   
[56] D. Kingma and J. Ba, “Adam: A method for stochastic optimization,” International Conference on Learning Representations, 12 2014.   
[57] P. Wang, “X-transformers,” GitHub, 2023. [Online]. Available: https://github.com/lucidrains/x-transformers   
[58] W. Falcon and The PyTorch Lightning team, “PyTorch Lightning,” 3 2019. [Online]. Available: https://github.com/Lightning-AI/lightning   
[59] A. Holtzman, J. Buys, L. Du, M. Forbes, and Y. Choi, “The curious case of neural text degeneration,” arXiv preprint arXiv:1904.09751, 2019.   
[60] K. Papineni, S. Roukos, T. Ward, and W.-J. Zhu, “Bleu: a method for automatic evaluation of machine translation,” in Proceedings of the 40th annual meeting of the Association for Computational Linguistics, 2002, pp. 311–318.   
[61] M. Popovi´c, “chrf: character n-gram f-score for automatic mt evaluation,” in Proceedings of the Tenth Workshop on Statistical Machine Translation, 2015, pp. 392–395.   
[62] V. I. Levenshtein et al., “Binary codes capable of correcting deletions, insertions, and reversals,” in Soviet physics doklady, vol. 10, no. 8. Soviet Union, 1966, pp. 707–710.   
[63] C.-Y. Lin, “Rouge: A package for automatic evaluation of summaries,” in Text summarization branches out, 2004, pp. 74–81.   
[64] S. Banerjee and A. Lavie, “Meteor: An automatic metric for mt evaluation with improved correlation with human judgments,” in Proceedings of the acl workshop on intrinsic and extrinsic evaluation measures for machine translation and/or summarization, 2005, pp. 65–72.   
[65] S. Lu, D. Guo, S. Ren, J. Huang, A. Svyatkovskiy, A. Blanco, C. Clement, D. Drain, D. Jiang, D. Tang et al., “Codexglue: A machine learning benchmark dataset for code understanding and generation,” arXiv preprint arXiv:2102.04664, 2021.   
[66] M. Evtikhiev, E. Bogomolov, Y. Sokolov, and T. Bryksin, “Out of the bleu: how should we assess quality of the code generation models?” arXiv preprint arXiv:2208.03133, 2022.   
[67] N. Cooper and R. Tufano. Replication package. [Online]. Available: https://github.com/RosaliaTufano/completeformer   
[68] Q. Lhoest, A. Villanova del Moral, Y. Jernite, A. Thakur, P. von Platen, S. Patil, J. Chaumond, M. Drame, J. Plu, L. Tunstall, J. Davison, M. Sˇ aˇsko, G. Chhablani, B. Malik, S. Brandeis, T. Le Scao, V. Sanh, C. Xu, N. Patry, A. McMillan-Major, P. Schmid, S. Gugger, C. Delangue, T. Matussie\`re, L. Debut, S. Bekman, P. Cistac, T. Goehringer, V. Mustar, F. Lagunas, A. Rush, and T. Wolf, “Datasets: A community library for natural language processing,” in Proceedings of the 2021 Conference on Empirical Methods in Natural Language Processing: System Demonstrations. Online and Punta Cana, Dominican Republic: Association for Computational Linguistics, Nov. 2021, pp. 175–184. [Online]. Available: https://aclanthology.org/2021.emnlp-demo.21   
[69] M. Allamanis, “The adverse effects of code duplication in machine learning models of code,” in Proceedings of the 2019 ACM SIGPLAN  

International Symposium on New Ideas, New Paradigms, and Reflections on Programming and Software, 2019, pp. 143–153. [70] S. Ren, D. Guo, S. Lu, L. Zhou, S. Liu, D. Tang, N. Sundaresan, M. Zhou, A. Blanco, and S. Ma, “Codebleu: a method for automatic evaluation of code synthesis,” arXiv preprint arXiv:2009.10297, 2020.  