# On-Device Qwen2.5: Efficient LLM Inference with Model Compression and Hardware Acceleration  

Maoyang Xiang∗, Ramesh Fernando∗, Bo Wang Singapore University of Technology and Design Email: maoyang xiang@sutd.edu.sg, ramesh fernando $@$ mymail.sutd.edu.sg, bo wang $@$ sutd.edu.sg  

Abstract—Transformer-based Large Language Models (LLMs) have significantly advanced AI capabilities but pose considerable challenges for deployment on edge devices due to high computational demands, memory bandwidth constraints, and energy consumption. This paper addresses these challenges by presenting an efficient framework for deploying the Qwen2.5-0.5B model on the Xilinx Kria KV260 edge platform, a heterogeneous system integrating an ARM Cortex-A53 CPU with reconfigurable FPGA logic. Leveraging Activation-aware Weight Quantization (AWQ) with FPGA-accelerated execution pipelines, the proposed approach enhances both model compression rate and system throughput. Additionally, we propose a hybrid execution strategy that intelligently offloads compute-intensive operations to the FPGA while utilizing the CPU for lighter tasks, effectively balancing the computational workload and maximizing overall performance. Our framework achieves a model compression rate of $55.08\%$ compared to the original model and produces output at a rate of 5.1 tokens per second, outperforming the baseline performance of 2.8 tokens per second.  

Index Terms—LLMs, edge AI, FPGA, acceleration  

# I. INTRODUCTION  

Recent advancements in Large Language Models (LLMs) have spurred numerous opportunities across different domains [1], attracting users from sectors such as healthcare [2], robotics [3], biomedical [4], music [5], etc. However, the growing adoption of these models has imposed immense computational demands, particularly for state-of-the-art models like GPT-4 [6], DeepSeek-V3 [7], and PaLM 2 [8], which are typically confined to power-intensive data centers. In contrast, there is a rising need to deploy lightweight LLMs on edge devices to enable real-time responses in wirelessdenied environments and enhance privacy protection [9]. In this work, we propose an efficient framework to accelerate on-device Qwen2.5-0.5B model inference.  

To implement it, we identify key challenges in deploying the model on resource-constrained edge devices and then employ the Xilinx Kria KV260 board, which incorporates the Kria K26 System-on-Module (SOM) (Fig. 1) as the target platform. Specifically, we identify significant challenges deteriorating the efficiency of model inference on Kria KV260 through a detailed analysis of the Qwen2.5-0.5B model, including both linear and non-linear operations.  

• Challenge 1: The limited memory capacity and bandwidth in the Programmable Logic (PL) side (e.g., Block RAMs, URAMs) restrict both the amount of model parameters that can be loaded and the efficiency of model loading, significantly impeding the deployment of on-device LLM inference.  

![](images/7c9dea6e3b9aa2a5a215e6328e48918ada87acf4ca24526c222fdd0d0815d279.jpg)  
Fig. 1: Simplified hardware architecture of Xilinx Kria K26 system-on-module (SOM) adapted from [10].  

Challenge 2: Matrix multiplications performed through Multiply-and-Accumulate (MAC) operations dominate the computational workload during inference, making them a performance bottleneck for LLM inference on edge devices.  

In this work, we address the challenges and achieve an excellent balance between accuracy, compression ratio, and tokens per second. The key contributions of our work are as follows.  

We exploit a model compression technique at the software level to optimize memory bandwidth utilization and minimize data transfer between off-chip memory and processing elements.   
We leverage the VFP4 floating point unit in ARM CortexA53 and parallelism of the FPGA fabric and successfully realize end-to-end inference of the Qwen2.5-0.5B model.   
We further design an accelerator that can expedite matrix multiplications in the workload with piplined weight unpacking and dequantization.   
• We achieve a model compression rate of $55.1\%$ and obtain an output rate of 5.1 tokens per second, surpassing the baseline performance of 2.8 tokens per second.  

# II. BACKGROUND AND RELATED WORK  

This section provides an overview of the Qwen2.5 model architecture and the AWQ-based model compression technique.  

![](images/9013120cb1054e55c2a643e9fa0885f0b0570f553dadf896d713189dd382f5e4.jpg)  
Fig. 2: AWQ uncovers that (a) keeping only $1\%$ of salient weights in FP16 can achieve a similar accuracy compared to the original model but not hardware friendly; (b) following activation awareness and performing per-channel scaling can protect the salient weights and reduce quantization error. The figure is adapted from work [11].  

# A. The Qwen2.5 model and the Transformer Architecture  

The Transformer architecture [12] has become the foundation of modern large language models, primarily due to its encoder-decoder structure. In particular, the Qwen2.5 model series [13], [14] adopts a decoder-only architecture that utilizes an auto-regressive approach for sequential text generation [15]. However, this inherently sequential decoding process poses significant computational challenges.  

Specifically, the decoder architecture in the Qwen2.5 model consists of a prefill stage and a decode stage. The prefill stage is characterized by highly parallel matrix-matrix operations while the decode stage is dominated by sequential matrixvector multiplications. Consequently, accelerating matrix multiplications becomes crucial for optimizing compute efficiency and minimizing latency, particularly for applications requiring real-time inference capabilities.  

# B. Model compression with AWQ  

Activation-aware Weight Quantization (AWQ) [11] is a powerful model compression technique to significantly reduce memory footprint and lower memory bandwidth requirements. As illustrated in Fig. 2, only $1\%$ of the weights can have a significant impact on model performance. Therefore, carefully preserving those salient weights can maintain performance and minimize quantization error. Specifically, AWQ performs perchannel scaling based on activation distribution, so that the entire weight matrix can be quantized to lower precisions (e.g., INT4 and INT3) but still enjoy high performance. AWQ does not rely on model training or reconstruction. It utilizes a grouping mechanism to share the same scaling parameters with a default Group Size (GS) of 128. This grouping allows AWQ to accurately capture variations in weight distributions across different channels, effectively reducing quantization error and maintaining high model accuracy despite using low-precision representations.  

We believe such model compression is particularly advantageous in edge deployment scenarios, such as the KV260 platform which is constrained by a memory bandwidth of 19.2 GB/s. Our implementation extends AWQ’s benefits through a customized weight packing scheme, ensuring efficient delivery of the quantized weights (i.e., qweights), scaling factors, and zero values to the Processing Elements. This packing scheme facilitates on-the-fly dequantization, optimizing both performance and compute efficiency.  

# C. Related Work  

The utilization of FPGA to accelerate LLM inference has garnered significant interest from both academia and industry due to their exceptional energy efficiency, reconfigurability, and flexibility. A recent study [16] has introduced specialized spatial accelerators designed for efficient FPGA-based LLM inference, revealing the potential of FPGA platforms to provide customized, high-performance solutions. Particularly, the work in [17] has achieved substantial improvements in both performance and power efficiency after deploying the TinyLlama 1.1B model [18] on the Xilinx ZCU102 platform, demonstrating the feasibility of FPGA-based deployments in edge inference applications.  

# III. PROPOSED SOFTWARE-HARDWARE CO-OPTIMIZATION  

We perform an in-depth analysis of the computational load and delay associated with the Qwen2.5-0.5B model. Table I presents a latency breakdown of the Qwen2.5-0.5B model during inference when deployed on the PS of the KV260 platform, using the compiler optimizations to utilize all four ARM Cortex-A53 cores. It reveals that $91.6\%$ of the inference time is dominated by MAC, which are the fundamental operations in matrix-matrix and matrix-vector multiplications. Note that the reported time in Table I accounts for both computation and memory access latency. This observation implies two key opportunities to improve the inference efficiency, which are (1) expediting compute-intensive operations using an accelerator and (2) compressing weight parameters in a data block so that it can be optimally stored in memory and transmitted to the accelerator with minimal bandwidth, improving memory bandwidth utilization.  

TABLE I: Inference latency breakdown for Qwen2.5-0.5B model when deployed on the Processing System of the KV260 platform with -Ofast and SIMD optimizations.   

![](images/0604e9ae79dbecb8cf9c2dbec020c143c51d1d929b2d24ee4c32156478137bf7.jpg)  

# A. Software Optimization  

We exploit the AWQ framework [11] to improve memory bandwidth utilization during inference. As Fig. 3 illustrates, we pack the quantized weights, scales, and zeros in a data block. This enhances utilization of memory bandwidth when streaming data to the PL using 4 channels, each with 128-bit data. The accelerator in the PL can unpack weights, dequantize weights, and perform MAC operations using a pipelined architecture to exploit parallelism. We further modify the original weight mapping structure of AWQ to accommodate AWQ MACRO. As Fig. 3 depicts, an AWQ MACRO packs Group Size $(\mathbf{G}\mathbf{S})\times8$ of quantized weights, 8 scales, and 8 zeros that are used to dequantize the weights in INT4 to FP32 prior to the pre-fill stage and decode stage. Since we need only 8 zero values in INT4 precision (i.e., 32 bits) to dequantize an AWQ MACRO, the remaining 96 bits out of the 128-bit strip in each macro are padded with zero.  

Our model compression approach incorporates several key features. First, data in an AWQ MACRO is streamed to the PL where dequantization and MAC operations are executed in a pipelined manner for improved efficiency. Second, the packing scheme ensures that the quantized weights are stored with their respective zero values and scale factors, enabling efficient per-channel dequantization. Lastly, the packing process is performed with a GS of 64 due to the higher accuracy score we achieved with the WNLI benchmark other than a GS of 128. The on-device inference of the Qwen2.5 model is implemented in C [19]. The model parameters (e.g., weights) are saved in a binary file while the model architecture is saved to a JSON file. Our approach is fully automated, allowing for seamlessly inference deployment on the KV260 platform with the AutoAWQ library [11], the binary file, and the JSON file.  

![](images/0a0a2f9fd6c9eba82abf5959a06b88d62b8b78f1f10a79d8a550185b5a6d6f40.jpg)  
Fig. 3: Customized weight compression in the memory via AWQ MACRO, a block with scales, zeros, and quantized weights in INT4.  

# B. Hardware Optimization  

We optimize the hardware to support AWQ implementation as well as accelerate matrix computations. To efficiently handle data transfer, we utilize four Advanced eXtensible Interface (AXI) channels, streaming data directly into custom-designed MACRO MAC units. Fig. 4(a) illustrates the memory access patterns, which ensure high throughput and structured data flow in the AXI channels. AWQ MACROs are carefully arranged in the memory as described in Section III-A, which ensures a one-to-one correspondence between the dequantized values and their respective positions in the original weight matrix. The 4 MACRO MAC units can process data in parallel since the 4-AXI channels are independent.  

The unpacking unit (Fig. 4(b)) unpacks scales, zeros, and quantized weights (i.e., qweights) into a 128-bit format, respectively. The qweights block, which has been packed in a 32-bit integer format, is subsequently decomposed into 8 separate chunks in INT4 through a shift operation with a bit mask. The zero blocks undergo a similar disassembly process. It is worthwhile noting that the scales remain the original FP16 format throughout this stage. The unpacked qweights, zeros, and scales are then sent to the MACRO MAC units for weight dequantization before multiplying with input activations. We design an $8\times8$ Processing Elements (PE) array in PL so that the multiplications can be done in parallel. Fig. 4(d) illustrates the operations in a PE, where zero value is subtracted from the qweight and the input activation is multiplied with the scale value. The partial sums from the PE array are accumulated subsequently with an adder tree. Once accumulations for an output channel are completed, the total sum will be transferred to the Processing System (PS) for non-linear operation computation.  

Table II presents the synthesis results of our accelerator, which operates at a frequency of $200~\mathrm{MHz}$ . As the KV260 platform does not inherently support lower precision floating point formats, all MAC operations are performed in FP32.  

![](images/b98a89c1287b57e8647966117ae686675eae1779680b845f8a9a23197d663f8f.jpg)  
Fig. 4: (a) Order of loading AWQ MACRO to the MAC units using 4 AXI channels (b) Unpacking unit which unpacks the AWQ MACRO (c) MACRO MAC Unit with PE arrays, a sliding window in grey is used for accumulation of $p_{-}s u m$ along the columns using the adder tree (d) Operations performed inside of a PE element.  

TABLE II: Synthesized resource utilization for the accelerator   

![](images/4faaa601dd46b66f6007f282fe5dabc23543726fc67999a7ab2b9a3b4b361ec2.jpg)  

# IV. EVALUATION  

The performance of our software-hardware co-optimization framework has been evaluated against a baseline model in terms of accuracy, model size, throughput, and a benchmark score. The results are summarized in Table III. Our compression approach results in a substantial reduction in model size. Specifically, the size decreases from $988~\mathrm{MB}$ in the baseline model to 443.81 MB, achieving a reduction of $55.1\%$ in memory footprint. Moreover, the inference performance improves significantly from 2.8 tokens per second in the baseline to 5.1 tokens per second, nearly doubling the throughput.  

TABLE III: Evaluation Results   

![](images/879bd2b3074b5ad1ca3e6a43ba91d0d85bf71fe63ef99161e11a113cb8f87d65.jpg)  

∗Based on co-simulation results.  

$$
\begin{array}{r l r}{\lefteqn{T o t_{1s t}=0.4\times\frac{R a t i o_{a c c u r a c y}}{\mathrm{MAX}(R a t i o_{a c c u r a c y})}}}\\ &{}&\\ &{}&{~+0.2\times\frac{R a t i o_{m e m o r y}}{\mathrm{MAX}(R a t i o_{m e m o r y})}}\\ &{}&{~+0.2\times\frac{R a t i o_{t h r o u t_{L}P r}}{\mathrm{MAX}(R a t i o_{t h r o u g h p u t_{L}P})}}\\ &{}&\\ &{}&{~+0.2\times\frac{R a t i o_{t h r o u g h p u t_{L}P}}{\mathrm{MAX}(R a t i o_{t h r o u g h p u t_{L}D})}}\end{array}
$$  

Moreover, we adopt Equation (1) to generate the benchmark score for a comprehensive evaluation. Specifically, the accuracy ratio represents how accurately the model can perform with the WNLI [20] benchmark. The memory ratio shows how well the model can be compressed compared to the original model size. The throughput at the prefill stage and the decode stage represents how efficiently the tokens can be processed at each stage, respectively. We achieve a score of 0.55 compared to the baseline score of 0.4.  

# V. CONCLUSION  

Our work presents an end-to-end inference framework that harnesses the synergetic strength of the Processing System and Programmable Logic on an FPGA platform to enable efficient deployment of the Qwen2.5-0.5B model. Our framework achieves a high compression rate that reduces memory footprint and facilitates higher memory bandwidth utilization when transferring the model parameters from off-chip memory to the PS. Moreover, we propose a hardware accelerator by utilizing a PE array with adder tree accumulation, expediting the performance of matrix multiplications. The gains in both model size and throughput make it highly beneficial for LLM inference deployment in resource-constrained environments.  

# REFERENCES  

[1] R. Bommasani, D. A. Hudson, E. Adeli, R. Altman, S. Arora, S. von Arx, et al., “On the opportunities and risks of foundation models,” 2022. Available at https://arxiv.org/abs/2108.07258.   
[2] C. Peng, X. Yang, A. Chen, K. E. Smith, N. PourNejatian, A. B. Costa, C. Martin, M. G. Flores, Y. Zhang, T. Magoc, G. Lipori, D. A. Mitchell, N. S. Ospina, M. M. Ahmed, W. R. Hogan, E. A. Shenkman, Y. Guo, J. Bian, and Y. Wu, “A study of generative large language model for medical research and healthcare,” npj Digital Medicine, vol. 6, Nov. 2023.   
[3] F. Zeng, W. Gan, Y. Wang, N. Liu, and P. S. Yu, “Large language models for robotics: A survey,” 2023. Available at https://arxiv.org/abs/ 2311.07226.   
[4] W. Lan, Z. Tang, M. Liu, Q. Chen, W. Peng, Y. P. Chen, and Y. Pan, “The large language models on biomedical data analysis: A survey,” IEEE Journal of Biomedical and Health Informatics, pp. 1–13, 2025. [5] R. Yuan, H. Lin, Y. Wang, Z. Tian, S. Wu, T. Shen, et al., “ChatMusician: Understanding and generating music intrinsically with LLM,” in Findings of the Association for Computational Linguistics: ACL 2024, (Bangkok, Thailand), pp. 6252–6271, Association for Computational Linguistics, Aug. 2024.   
[6] OpenAI, A. Josh, A. Steven, A. Sandhini, A. Lama, A. Ilge, A. Florencia, A. Diogo, A. Janko, A. Sam, A. Shyamal, A. Red, B. Igor, B. Suchir, B. Valerie, B. Paul, B. Haiming, B. Mohammad, B. Jeff, and Z. Barret, “Gpt-4 technical report,” 03 2023. Available at 10.48550/arXiv.2303. 08774.   
[7] DeepSeek-AI, “Deepseek-v3 technical report,” 2024. Available at https: //arxiv.org/abs/2412.19437.   
[8] R. Anil, A. M. Dai, O. Firat, M. Johnson, D. Lepikhin, A. Passos, et al., “Palm 2 technical report,” 2023. Available at https://arxiv.org/abs/2305. 10403.   
[9] H. Hua, Y. Li, T. Wang, N. Dong, W. Li, and J. Cao, “Edge computing with artificial intelligence: A machine learning perspective,” ACM Comput. Surv., vol. 55, Jan. 2023.   
[10] AMD Xilinx, Kria K26 SOM Data Sheet. AMD, 2021. DS987 (v1.5), May 18, 2021.   
[11] J. Lin, J. Tang, H. Tang, S. Yang, W.-M. Chen, W.-C. Wang, G. Xiao, X. Dang, C. Gan, and S. Han, “Awq: Activation-aware weight quantization for llm compression and acceleration,” in MLSys, 2024.   
[12] A. Vaswani, N. Shazeer, N. Parmar, J. Uszkoreit, L. Jones, A. N. Gomez, L. u. Kaiser, and I. Polosukhin, “Attention is all you need,” in Advances in Neural Information Processing Systems (I. Guyon, U. V. Luxburg, S. Bengio, H. Wallach, R. Fergus, S. Vishwanathan, and R. Garnett, eds.), vol. 30, Curran Associates, Inc., 2017.   
[13] A. Yang, B. Yang, B. Hui, B. Zheng, B. Yu, C. Zhou, C. Li, C. Li, D. Liu, F. Huang, et al., “Qwen2 technical report,” arXiv preprint arXiv:2407.10671, 2024.   
[14] Q. Team, “Qwen2.5: A party of foundation models,” September 2024. Available at https://qwenlm.github.io/blog/qwen2.5/.   
[15] H. Touvron, L. Martin, K. Stone, P. Albert, A. Almahairi, Y. Babaei, et al., “Llama 2: Open foundation and fine-tuned chat models,” 2023. Available at https://arxiv.org/abs/2307.09288.   
[16] H. Chen, J. Zhang, Y. Du, S. Xiang, Z. Yue, N. Zhang, Y. Cai, and Z. Zhang, “Understanding the potential of FPGA-based spatial acceleration for large language model inference,” ACM Transactions on Reconfigurable Technology and Systems, vol. 18, no. 1, pp. 1–23, 2024.   
[17] H. Xu, Y. Li, and S. Ji, “Llamaf: An efficient llama2 architecture accelerator on embedded fpgas,” in 2024 IEEE 10th World Forum on Internet of Things (WF-IoT), pp. 1–7, 2024.   
[18] P. Zhang, G. Zeng, T. Wang, and W. Lu, “Tinyllama: An open-source small language model,” 2024. Available at https://arxiv.org/abs/2401. 02385.   
[19] A. Karpathy, “llama2.c: Inference of llama2 in one file of pure c,” 2023. Available at https://github.com/karpathy/llama2.c.   
[20] S. Elfwing, E. Uchibe, and K. Doya, “Sigmoid-weighted linear units for neural network function approximation in reinforcement learning,” 2017. Available at https://arxiv.org/abs/1702.03118.  